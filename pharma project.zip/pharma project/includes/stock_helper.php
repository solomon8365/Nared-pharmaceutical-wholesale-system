<?php

function log_stock_movement(PDO $pdo, int $productId, int $quantityChange, string $reason, ?string $refType = null, ?int $refId = null): void
{
    $stmt = $pdo->prepare('INSERT INTO stock_movements (product_id, quantity_change, reason, reference_type, reference_id, created_at) VALUES (:pid, :qty, :reason, :ref_type, :ref_id, NOW())');
    $stmt->execute([
        'pid' => $productId,
        'qty' => $quantityChange,
        'reason' => $reason,
        'ref_type' => $refType,
        'ref_id' => $refId,
    ]);
}

function deduct_from_batches(PDO $pdo, int $productId, int $needQty): void
{
    $stmt = $pdo->prepare('SELECT id, quantity FROM product_batches WHERE product_id = :pid AND quantity > 0 ORDER BY expiry_date ASC, id ASC FOR UPDATE');
    $stmt->execute(['pid' => $productId]);
    $batches = $stmt->fetchAll();

    if (!empty($batches)) {
        $remaining = $needQty;
        foreach ($batches as $batch) {
            if ($remaining <= 0) break;
            $take = min((int) $batch['quantity'], $remaining);
            $remaining -= $take;
            $pdo->prepare('UPDATE product_batches SET quantity = quantity - :qty WHERE id = :id')
                ->execute(['qty' => $take, 'id' => $batch['id']]);
        }
        if ($remaining > 0) {
            throw new RuntimeException('Insufficient stock (batch tracked).');
        }
    } else {
        $st = $pdo->prepare('SELECT stock_quantity FROM products WHERE id = :id FOR UPDATE');
        $st->execute(['id' => $productId]);
        $avail = (int) $st->fetchColumn();
        if ($avail < $needQty) {
            throw new RuntimeException('Insufficient stock.');
        }
    }

    $pdo->prepare('UPDATE products SET stock_quantity = stock_quantity - :qty WHERE id = :id')
        ->execute(['qty' => $needQty, 'id' => $productId]);
}
