<?php
require_once __DIR__ . '/auth.php';
$user = currentUser();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="assets/css/style.css?v=2">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="assets/js/app.js"></script>
</head>
<body>
<nav class="topbar">
    <div class="brand"><?= htmlspecialchars(APP_NAME) ?></div>
    <?php if ($user): ?>
    <div class="nav-links">
        <a href="index.php?page=dashboard">Dashboard</a>
        <?php if (isAdmin()): ?>
            <a href="index.php?page=products">Products</a>
            <a href="index.php?page=categories">Categories</a>
            <a href="index.php?page=suppliers">Suppliers</a>
            <a href="index.php?page=customers">Customers</a>
            <a href="index.php?page=sales">Sales</a>
            <a href="index.php?page=reports">Reports</a>
            <a href="index.php?page=stock_movements">Stock Log</a>
            <a href="index.php?page=expiry_alerts" style="color:#ef4444;font-weight:700">Expiry Alerts</a>
            <a href="index.php?page=price_history">Price Changes</a>
            <a href="index.php?page=supplier_payments">Payments</a>
            <a href="index.php?page=commissions">Commissions</a>
            <a href="index.php?page=customer_order_queue">Order approvals</a>
        <?php elseif (isCustomer()): ?>
            <a href="index.php?page=catalog">Products</a>
            <a href="index.php?page=place_order">Place order</a>
            <a href="index.php?page=my_orders">My orders</a>
        <?php endif; ?>
    </div>
    <a href="index.php?page=logout" class="logout">Logout</a>
    <?php endif; ?>
</nav>
<main class="container">
