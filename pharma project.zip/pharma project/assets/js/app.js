$(document).ready(function () {
    let rowIndex = 1;

    function buildOrderRow(index) {
        const productOptions = $('select[name="items[0][product_id]"]').html();
        const row = $('<div class="order-item-row"></div>');
        row.append('<select name="items[' + index + '][product_id]" required>' + productOptions + '</select>');
        row.append('<input type="number" name="items[' + index + '][quantity]" value="1" min="1" required>');
        row.append('<input type="text" name="items[' + index + '][batch_number]" placeholder="Batch #" style="min-width:90px">');
        row.append('<input type="date" name="items[' + index + '][expiry_date]" style="min-width:130px">');
        row.append('<input type="number" step="0.01" name="items[' + index + '][purchase_price]" placeholder="Cost" style="min-width:90px">');
        row.append('<button type="button" class="remove-item">Remove</button>');
        return row;
    }

    $('#add-order-item').on('click', function () {
        $('#order-items').append(buildOrderRow(rowIndex));
        rowIndex++;
    });

    $('body').on('click', '.remove-item', function () {
        $(this).closest('.order-item-row').remove();
    });

    let saleRowIndex = 1;

    function buildSaleRow(index) {
        const productOptions = $('select[name="sale_items[0][product_id]"]').html();
        const row = $('<div class="order-item-row"></div>');
        row.append('<select name="sale_items[' + index + '][product_id]" required>' + productOptions + '</select>');
        row.append('<input type="number" name="sale_items[' + index + '][quantity]" value="1" min="1" required>');
        row.append('<button type="button" class="remove-item">Remove</button>');
        return row;
    }

    $('#add-sale-item').on('click', function () {
        $('#sale-items').append(buildSaleRow(saleRowIndex));
        saleRowIndex++;
    });

    let requestRowIndex = 1;

    function buildRequestRow(index) {
        const productOptions = $('select[name="request_items[0][product_id]"]').html();
        const row = $('<div class="order-item-row"></div>');
        row.append('<select name="request_items[' + index + '][product_id]" required>' + productOptions + '</select>');
        row.append('<input type="number" name="request_items[' + index + '][quantity]" value="1" min="1" required>');
        row.append('<button type="button" class="remove-item">Remove</button>');
        return row;
    }

    $('#add-request-item').on('click', function () {
        $('#request-items').append(buildRequestRow(requestRowIndex));
        requestRowIndex++;
    });
});
