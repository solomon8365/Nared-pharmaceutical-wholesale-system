<?php
require_once __DIR__ . '/auth.php';

$page = $_GET['page'] ?? 'dashboard';
$publicPages = ['login', 'register', 'catalog'];
$standalonePages = ['login', 'register', 'catalog', 'receipt'];

if ($page === 'logout') {
    logout();
}

if (!in_array($page, $publicPages, true)) {
    requireLogin();
}

$allowedPages = [
    'dashboard',
    'products',
    'categories',
    'suppliers',
    'orders',
    'reports',
    'stock_movements',
    'price_history',
    'expiry_alerts',
    'supplier_payments',
    'commissions',
    'receipt',
    'customers',
    'sales',
    'customer_order_queue',
    'place_order',
    'my_orders',
    'login',
    'register',
    'catalog',
    '404',
];
$page = in_array($page, $allowedPages, true) ? $page : '404';

$customerPages = ['dashboard', 'place_order', 'my_orders', 'catalog'];
if (currentUser() && isCustomer() && !in_array($page, $customerPages, true)) {
    header('Location: index.php?page=dashboard');
    exit;
}
if (currentUser() && isAdmin() && in_array($page, ['place_order', 'my_orders'], true)) {
    header('Location: index.php?page=dashboard');
    exit;
}

if (!in_array($page, $standalonePages, true)) {
    require_once __DIR__ . '/header.php';
}

require_once __DIR__ . '/pages/' . $page . '.php';

if (!in_array($page, $standalonePages, true)) {
    require_once __DIR__ . '/footer.php';
}
