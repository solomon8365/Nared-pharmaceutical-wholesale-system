<?php
require_once __DIR__ . '/db.php';

try {
    $pdo = getPDO();
    echo '<!DOCTYPE html>';
    echo '<html lang="en">';
    echo '<head><meta charset="UTF-8"><title>DB Connection Test</title></head>';
    echo '<body style="font-family:Arial,sans-serif;padding:30px;">';
    echo '<h1>Database Connection Test</h1>';
    echo '<p style="color:green;">Connection successful!</p>';
    echo '<p>Database: ' . htmlspecialchars(DB_NAME) . '</p>';
    echo '<p><a href="index.php">Return to app</a></p>';
    echo '</body></html>';
} catch (Exception $e) {
    echo '<!DOCTYPE html>';
    echo '<html lang="en">';
    echo '<head><meta charset="UTF-8"><title>DB Connection Test</title></head>';
    echo '<body style="font-family:Arial,sans-serif;padding:30px;">';
    echo '<h1>Database Connection Test</h1>';
    echo '<p style="color:red;">Connection failed:</p>';
    echo '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
    echo '<p><a href="index.php">Return to app</a></p>';
    echo '</body></html>';
}
