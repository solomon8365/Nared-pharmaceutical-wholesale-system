</main>
<footer class="site-footer">
    <p>© <?= date('Y') ?> <?= htmlspecialchars(APP_NAME) ?>. Built for pharmacy distribution management.</p>
</footer>
</body>
</html>
