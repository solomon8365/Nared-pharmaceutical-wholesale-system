<?php
// Database and application configuration
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'pharma');
define('DB_USER', 'root');
define('DB_PASS', '');
define('APP_NAME', 'NARED PHARMACON');
define('APP_BASE', '');
define('PRODUCT_UPLOAD_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'products');
define('PRODUCT_UPLOAD_URL', 'uploads/products');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('CURRENCY', 'ETB');

function fmt(float $amount): string
{
    return CURRENCY . ' ' . number_format($amount, 2);
}
