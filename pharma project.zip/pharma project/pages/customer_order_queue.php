<?php
requireAdmin();
$pdo = getPDO();
$messages = [];
$viewId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $orderId = (int) ($_POST['customer_order_id'] ?? 0);

    if ($orderId <= 0) {
        $messages[] = ['type' => 'error', 'text' => 'Invalid order.'];
    } elseif ($action === 'reject') {
        $note = trim($_POST['admin_note'] ?? '');
        $stmt = $pdo->prepare("UPDATE customer_orders SET status = 'rejected', admin_note = :note, processed_at = NOW() WHERE id = :id AND status = 'pending'");
        $stmt->execute(['note' => $note !== '' ? $note : null, 'id' => $orderId]);
        if ($stmt->rowCount() === 0) {
            $messages[] = ['type' => 'error', 'text' => 'Order could not be rejected (not pending or missing).'];
        } else {
            $messages[] = ['type' => 'success', 'text' => 'Order rejected.'];
        }
    } elseif ($action === 'approve') {
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT * FROM customer_orders WHERE id = :id AND status = 'pending' FOR UPDATE");
            $stmt->execute(['id' => $orderId]);
            $co = $stmt->fetch();
            if (!$co) {
                throw new RuntimeException('Order not found or already processed.');
            }

            $itemsStmt = $pdo->prepare('SELECT product_id, quantity, unit_price FROM customer_order_items WHERE customer_order_id = :id');
            $itemsStmt->execute(['id' => $orderId]);
            $rows = $itemsStmt->fetchAll();
            if (empty($rows)) {
                throw new RuntimeException('Order has no line items.');
            }

            $lineTotals = [];
            foreach ($rows as $row) {
                $pid = (int) $row['product_id'];
                $qty = (int) $row['quantity'];
                if ($pid <= 0 || $qty <= 0) {
                    continue;
                }
                $lineTotals[] = ['product_id' => $pid, 'quantity' => $qty, 'unit_price' => (float) $row['unit_price']];
            }
            if (empty($lineTotals)) {
                throw new RuntimeException('Invalid line items.');
            }

            $qtyByProduct = [];
            foreach ($lineTotals as $line) {
                $pid = $line['product_id'];
                $qtyByProduct[$pid] = ($qtyByProduct[$pid] ?? 0) + $line['quantity'];
            }

            $priceByProduct = [];
            foreach ($qtyByProduct as $productId => $needQty) {
                $pstmt = $pdo->prepare('SELECT price, stock_quantity FROM products WHERE id = :id FOR UPDATE');
                $pstmt->execute(['id' => $productId]);
                $prow = $pstmt->fetch();
                if (!$prow) {
                    throw new RuntimeException('Product no longer exists.');
                }
                if ((int) $prow['stock_quantity'] < $needQty) {
                    throw new RuntimeException('Insufficient stock to approve this order.');
                }
                $priceByProduct[$productId] = (float) $prow['price'];
            }

            $linesForInsert = [];
            foreach ($lineTotals as $line) {
                $linesForInsert[] = [
                    'product_id' => $line['product_id'],
                    'quantity' => $line['quantity'],
                    'unit_price' => $priceByProduct[$line['product_id']],
                ];
            }

            $total = 0;
            foreach ($linesForInsert as $line) {
                $total += $line['unit_price'] * $line['quantity'];
            }

            $customerId = (int) $co['customer_id'];
            $saleDate = $co['order_date'];

            $insSale = $pdo->prepare('INSERT INTO sales (customer_id, sale_date, total_amount, created_at) VALUES (:customer, :sale_date, :total, NOW())');
            $insSale->execute(['customer' => $customerId, 'sale_date' => $saleDate, 'total' => $total]);
            $saleId = (int) $pdo->lastInsertId();

            $insertItem = $pdo->prepare('INSERT INTO sale_items (sale_id, product_id, quantity, unit_price) VALUES (:sale_id, :product_id, :quantity, :unit_price)');
            foreach ($linesForInsert as $line) {
                $insertItem->execute([
                    'sale_id' => $saleId,
                    'product_id' => $line['product_id'],
                    'quantity' => $line['quantity'],
                    'unit_price' => $line['unit_price'],
                ]);
                $pdo->prepare('UPDATE products SET stock_quantity = stock_quantity - :qty WHERE id = :id')
                    ->execute(['qty' => $line['quantity'], 'id' => $line['product_id']]);
                deduct_from_batches($pdo, $line['product_id'], $line['quantity']);
            }

            $pdo->prepare("UPDATE customer_orders SET status = 'approved', sale_id = :sale_id, processed_at = NOW(), admin_note = NULL WHERE id = :id")
                ->execute(['sale_id' => $saleId, 'id' => $orderId]);

            $pdo->commit();
            $messages[] = ['type' => 'success', 'text' => 'Order approved; sale recorded and stock updated.'];
        } catch (Exception $e) {
            $pdo->rollBack();
            $messages[] = ['type' => 'error', 'text' => $e->getMessage()];
        }
    }
}

$filterStatus = trim($_GET['status'] ?? '');
$filterCust = trim($_GET['customer'] ?? '');
$where = [];
$params = [];
if ($filterStatus !== '') {
    $where[] = 'co.status = :status';
    $params['status'] = $filterStatus;
}
if ($filterCust !== '') {
    $where[] = 'c.name LIKE :customer';
    $params['customer'] = "%$filterCust%";
}
$sql = "SELECT co.id, co.order_date, co.total_amount, co.status, co.payment_method, co.created_at, c.name AS customer_name
    FROM customer_orders co
    LEFT JOIN customers c ON co.customer_id = c.id";
if (!empty($where)) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= " ORDER BY co.status = 'pending' DESC, co.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$list = $stmt->fetchAll();

$detail = null;
$detailItems = [];
if ($viewId > 0) {
    $dstmt = $pdo->prepare("SELECT co.*, c.name AS customer_name, u.username AS placed_by
        FROM customer_orders co
        LEFT JOIN customers c ON co.customer_id = c.id
        LEFT JOIN users u ON co.placed_by_user_id = u.id
        WHERE co.id = :id");
    $dstmt->execute(['id' => $viewId]);
    $detail = $dstmt->fetch();
    if ($detail) {
        $istmt = $pdo->prepare('SELECT coi.quantity, coi.unit_price, p.name AS product_name FROM customer_order_items coi JOIN products p ON coi.product_id = p.id WHERE coi.customer_order_id = :id');
        $istmt->execute(['id' => $viewId]);
        $detailItems = $istmt->fetchAll();
    } else {
        $messages[] = ['type' => 'error', 'text' => 'Order not found.'];
    }
}
?>
<section>
    <h1>Customer order queue</h1>
    <p class="hint">Review requests from customer accounts. Approving creates a sale and reduces inventory (same as Sales). Rejecting leaves stock unchanged.</p>
    <?php foreach ($messages as $message): ?>
        <div class="alert alert-<?= htmlspecialchars($message['type']) ?>"><?= htmlspecialchars($message['text']) ?></div>
    <?php endforeach; ?>

    <?php if ($detail): ?>
        <div class="panel">
            <p><a href="index.php?page=customer_order_queue">← Back to list</a></p>
            <h2>Order #<?= htmlspecialchars((string) $detail['id']) ?></h2>
            <table>
                <tbody>
                    <tr><th>Customer</th><td><?= htmlspecialchars($detail['customer_name'] ?? '') ?></td></tr>
                    <tr><th>Date</th><td><?= htmlspecialchars($detail['order_date']) ?></td></tr>
                    <tr><th>Status</th><td><?= htmlspecialchars($detail['status']) ?></td></tr>
                    <tr><th>Total</th><td><?= number_format((float) $detail['total_amount'], 2) ?></td></tr>
                    <tr><th>Payment</th><td><?= htmlspecialchars($detail['payment_method'] ?? '') ?> — <?= htmlspecialchars($detail['payment_detail'] ?? '') ?></td></tr>
                    <tr><th>Placed by</th><td><?= htmlspecialchars($detail['placed_by'] ?? '') ?></td></tr>
                    <?php if (!empty($detail['sale_id'])): ?>
                        <tr><th>Sale ID</th><td><?= htmlspecialchars((string) $detail['sale_id']) ?></td></tr>
                    <?php endif; ?>
                    <?php if ($detail['admin_note']): ?>
                        <tr><th>Admin note</th><td><?= htmlspecialchars($detail['admin_note']) ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <h3>Line items</h3>
            <table>
                <thead><tr><th>Product</th><th>Qty</th><th>Unit price</th><th>Line total</th></tr></thead>
                <tbody>
                    <?php foreach ($detailItems as $it): ?>
                        <tr>
                            <td><?= htmlspecialchars($it['product_name']) ?></td>
                            <td><?= htmlspecialchars((string) $it['quantity']) ?></td>
                            <td><?= number_format((float) $it['unit_price'], 2) ?></td>
                            <td><?= number_format((float) $it['unit_price'] * (int) $it['quantity'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php if ($detail['status'] === 'pending'): ?>
                <div class="panel split order-actions">
                    <div class="panel-block">
                        <h3>Approve</h3>
                        <form method="post" class="form-grid">
                            <input type="hidden" name="action" value="approve">
                            <input type="hidden" name="customer_order_id" value="<?= htmlspecialchars((string) $detail['id']) ?>">
                            <button type="submit">Approve order</button>
                        </form>
                    </div>
                    <div class="panel-block">
                        <h3>Reject</h3>
                        <form method="post" class="form-grid">
                            <input type="hidden" name="action" value="reject">
                            <input type="hidden" name="customer_order_id" value="<?= htmlspecialchars((string) $detail['id']) ?>">
                            <label>Note to customer (optional)<textarea name="admin_note" rows="3"></textarea></label>
                            <button type="submit" class="btn-danger">Reject order</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="panel">
        <h2>All customer orders</h2>
        <form method="get" style="margin-bottom:12px;display:flex;gap:8px;flex-wrap:wrap">
            <input type="hidden" name="page" value="customer_order_queue">
            <select name="status" style="flex:1;min-width:120px;margin:0">
                <option value="">All statuses</option>
                <option value="pending"<?= $filterStatus === 'pending' ? ' selected' : '' ?>>Pending</option>
                <option value="approved"<?= $filterStatus === 'approved' ? ' selected' : '' ?>>Approved</option>
                <option value="rejected"<?= $filterStatus === 'rejected' ? ' selected' : '' ?>>Rejected</option>
            </select>
            <input type="text" name="customer" value="<?= htmlspecialchars($filterCust) ?>" placeholder="Customer name..." style="flex:1;min-width:120px;margin:0">
            <button type="submit" style="margin:0">Filter</button>
            <?php if ($filterStatus !== '' || $filterCust !== ''): ?><a href="?page=customer_order_queue" style="display:inline-flex;align-items:center;padding:0 12px;color:var(--brown-800);font-weight:600">Clear</a><?php endif; ?>
        </form>
        <table>
            <thead><tr><th>ID</th><th>Date</th><th>Customer</th><th>Total</th><th>Pay</th><th>Status</th><th></th></tr></thead>
            <tbody>
                <?php if (empty($list)): ?>
                    <tr><td colspan="7">No customer orders yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($list as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars((string) $row['id']) ?></td>
                            <td><?= htmlspecialchars($row['order_date']) ?></td>
                            <td><?= htmlspecialchars($row['customer_name'] ?? '') ?></td>
                            <td><?= number_format((float) $row['total_amount'], 2) ?></td>
                            <td><?= htmlspecialchars($row['payment_method'] ?? '') ?></td>
                            <td><span class="status-badge status-<?= htmlspecialchars($row['status']) ?>"><?= htmlspecialchars($row['status']) ?></span></td>
                            <td><a href="index.php?page=customer_order_queue&amp;id=<?= htmlspecialchars((string) $row['id']) ?>">View</a></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
