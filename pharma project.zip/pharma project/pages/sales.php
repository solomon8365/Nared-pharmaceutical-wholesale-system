<?php
requireAdmin();
require_once __DIR__ . '/../includes/stock_helper.php';
$pdo = getPDO();
$messages = [];
$products = $pdo->query('SELECT id, name, price, stock_quantity FROM products ORDER BY name')->fetchAll();
$customers = $pdo->query('SELECT id, name FROM customers ORDER BY name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerId = (int) ($_POST['customer_id'] ?? 0);
    $saleDate = $_POST['sale_date'] ?? date('Y-m-d');
    $items = $_POST['sale_items'] ?? [];
    $agentName = trim($_POST['agent_name'] ?? '');
    $commissionPercent = (float) ($_POST['commission_percent'] ?? 0);

    if ($customerId <= 0 || empty($items)) {
        $messages[] = ['type' => 'error', 'text' => 'Customer and at least one line item are required.'];
    } else {
        $pdo->beginTransaction();
        try {
            $lineTotals = [];
            foreach ($items as $item) {
                $productId = (int) ($item['product_id'] ?? 0);
                $quantity = (int) ($item['quantity'] ?? 0);
                if ($productId <= 0 || $quantity <= 0) {
                    continue;
                }
                $lineTotals[] = ['product_id' => $productId, 'quantity' => $quantity];
            }

            if (empty($lineTotals)) {
                throw new RuntimeException('Add at least one product with quantity.');
            }

            $qtyByProduct = [];
            foreach ($lineTotals as $line) {
                $pid = $line['product_id'];
                $qtyByProduct[$pid] = ($qtyByProduct[$pid] ?? 0) + $line['quantity'];
            }

            $priceByProduct = [];
            foreach ($qtyByProduct as $productId => $needQty) {
                $stmt = $pdo->prepare('SELECT price, stock_quantity FROM products WHERE id = :id FOR UPDATE');
                $stmt->execute(['id' => $productId]);
                $row = $stmt->fetch();
                if (!$row) {
                    throw new RuntimeException('Product not found.');
                }
                $stock = (int) $row['stock_quantity'];
                if ($stock < $needQty) {
                    throw new RuntimeException('Insufficient stock for one or more products.');
                }
                $priceByProduct[$productId] = (float) $row['price'];
            }

            $linesForInsert = [];
            foreach ($lineTotals as $line) {
                $linesForInsert[] = [
                    'product_id' => $line['product_id'],
                    'quantity' => $line['quantity'],
                    'unit_price' => $priceByProduct[$line['product_id']],
                ];
            }

            $total = 0;
            foreach ($linesForInsert as $line) {
                $total += $line['unit_price'] * $line['quantity'];
            }

            $commissionAmount = $commissionPercent > 0 ? round($total * $commissionPercent / 100, 2) : 0;

            $stmt = $pdo->prepare('INSERT INTO sales (customer_id, sale_date, total_amount, agent_name, commission_percent, commission_amount, created_at) VALUES (:customer, :sale_date, :total, :agent, :cp, :ca, NOW())');
            $stmt->execute(['customer' => $customerId, 'sale_date' => $saleDate, 'total' => $total, 'agent' => $agentName ?: null, 'cp' => $commissionPercent > 0 ? $commissionPercent : null, 'ca' => $commissionAmount > 0 ? $commissionAmount : null]);
            $saleId = $pdo->lastInsertId();

            $insertItem = $pdo->prepare('INSERT INTO sale_items (sale_id, product_id, quantity, unit_price) VALUES (:sale_id, :product_id, :quantity, :unit_price)');
            foreach ($linesForInsert as $line) {
                $insertItem->execute([
                    'sale_id' => $saleId,
                    'product_id' => $line['product_id'],
                    'quantity' => $line['quantity'],
                    'unit_price' => $line['unit_price'],
                ]);
                deduct_from_batches($pdo, $line['product_id'], $line['quantity']);
                log_stock_movement($pdo, $line['product_id'], -$line['quantity'], 'Sale', 'sale', (int) $saleId);
            }

            $pdo->commit();
            $messages[] = ['type' => 'success', 'text' => 'Sale recorded successfully.'];
            $products = $pdo->query('SELECT id, name, price, stock_quantity FROM products ORDER BY name')->fetchAll();
        } catch (Exception $e) {
            $pdo->rollBack();
            $messages[] = ['type' => 'error', 'text' => $e->getMessage()];
        }
    }
}

$filterCustomer = (int) ($_GET['customer_id'] ?? 0);
$filterDateFrom = trim($_GET['date_from'] ?? '');
$filterDateTo = trim($_GET['date_to'] ?? '');
$where = [];
$params = [];
if ($filterCustomer > 0) {
    $where[] = 's.customer_id = :customer';
    $params['customer'] = $filterCustomer;
}
if ($filterDateFrom !== '') {
    $where[] = 's.sale_date >= :date_from';
    $params['date_from'] = $filterDateFrom;
}
if ($filterDateTo !== '') {
    $where[] = 's.sale_date <= :date_to';
    $params['date_to'] = $filterDateTo;
}
$sql = 'SELECT s.id, s.sale_date, s.total_amount, c.name AS customer_name FROM sales s LEFT JOIN customers c ON s.customer_id = c.id';
if (!empty($where)) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY s.created_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$sales = $stmt->fetchAll();
?>
<section>
    <h1>Sales</h1>
    <?php foreach ($messages as $message): ?>
        <div class="alert alert-<?= htmlspecialchars($message['type']) ?>"><?= htmlspecialchars($message['text']) ?></div>
    <?php endforeach; ?>

    <div class="panel split">
        <div class="panel-block">
            <h2>New Sale</h2>
            <?php if (empty($customers)): ?>
                <p class="hint">Add at least one customer before recording sales.</p>
            <?php elseif (empty($products)): ?>
                <p class="hint">Add products before recording sales.</p>
            <?php else: ?>
            <form method="post" class="form-grid" id="sale-form">
                <label>Customer (who is buying)
                    <select name="customer_id" required>
                        <option value="">— Select buyer —</option>
                        <?php foreach ($customers as $customer): ?>
                            <option value="<?= htmlspecialchars($customer['id']) ?>"><?= htmlspecialchars($customer['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Sale date<input type="date" name="sale_date" value="<?= date('Y-m-d') ?>"></label>
                <fieldset style="border:1px solid var(--brown-300);padding:12px;border-radius:6px;grid-column:1/-1">
                    <legend style="font-weight:600;color:var(--brown-800)">Products being sold</legend>
                    <div class="order-items" id="sale-items">
                        <div class="order-item-row">
                            <select name="sale_items[0][product_id]" required>
                                <option value="">— Select product —</option>
                                <?php foreach ($products as $product): ?>
                                    <option value="<?= htmlspecialchars($product['id']) ?>"><?= htmlspecialchars($product['name']) ?> — <?= fmt((float) $product['price']) ?> (stock <?= (int) $product['stock_quantity'] ?>)</option>
                                <?php endforeach; ?>
                            </select>
                            <input type="number" name="sale_items[0][quantity]" value="1" min="1" required style="width:80px">
                            <button type="button" class="remove-item">Remove</button>
                        </div>
                    </div>
                    <button type="button" id="add-sale-item" style="margin-top:8px">+ Add another product</button>
                </fieldset>
                <fieldset style="border:1px solid var(--brown-300);padding:12px;border-radius:6px;grid-column:1/-1">
                    <legend style="font-weight:600;color:var(--brown-800)">Commission (optional)</legend>
                    <div style="display:flex;gap:12px;flex-wrap:wrap">
                        <label style="flex:1">Sales agent name<input type="text" name="agent_name" placeholder="e.g. Abel"></label>
                        <label style="flex:1">Commission %<input type="number" name="commission_percent" min="0" max="100" step="0.1" value="0"></label>
                    </div>
                </fieldset>
                <button type="submit" style="grid-column:1/-1">Save Sale</button>
            </form>
            <?php endif; ?>
        </div>

        <div class="panel-block">
            <h2>Sale History</h2>
            <form method="get" style="margin-bottom:12px;display:flex;gap:8px;flex-wrap:wrap">
                <input type="hidden" name="page" value="sales">
                <select name="customer_id" style="flex:1;min-width:140px;margin:0">
                    <option value="">All customers</option>
                    <?php foreach ($customers as $cust): ?>
                        <option value="<?= htmlspecialchars($cust['id']) ?>"<?= $filterCustomer === (int) $cust['id'] ? ' selected' : '' ?>><?= htmlspecialchars($cust['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="date" name="date_from" value="<?= htmlspecialchars($filterDateFrom) ?>" style="margin:0" placeholder="From">
                <input type="date" name="date_to" value="<?= htmlspecialchars($filterDateTo) ?>" style="margin:0" placeholder="To">
                <button type="submit" style="margin:0">Filter</button>
                <?php if ($filterCustomer > 0 || $filterDateFrom !== '' || $filterDateTo !== ''): ?><a href="?page=sales" style="display:inline-flex;align-items:center;padding:0 12px;color:var(--brown-800);font-weight:600">Clear</a><?php endif; ?>
            </form>
            <table>
                <thead><tr><th>ID</th><th>Date</th><th>Customer</th><th>Total</th><th></th></tr></thead>
                <tbody>
                    <?php if (empty($sales)): ?>
                        <tr><td colspan="5">No sales recorded yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($sales as $sale): ?>
                            <tr>
                                <td><?= htmlspecialchars($sale['id']) ?></td>
                                <td><?= htmlspecialchars($sale['sale_date']) ?></td>
                                <td><?= htmlspecialchars($sale['customer_name'] ?? 'Unknown') ?></td>
                                <td><?= number_format($sale['total_amount'], 2) ?></td>
                                <td><a href="index.php?page=receipt&amp;id=<?= htmlspecialchars((string) $sale['id']) ?>" style="font-size:0.82rem;color:var(--brown-700)">Receipt</a></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
