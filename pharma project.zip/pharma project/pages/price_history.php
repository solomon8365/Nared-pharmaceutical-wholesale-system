<?php
requireAdmin();
$pdo = getPDO();

$productId = (int) ($_GET['product_id'] ?? 0);
$from  = $_GET['from'] ?? date('Y-m-d', strtotime('-90 days'));
$to    = $_GET['to'] ?? date('Y-m-d');

$sql = 'SELECT ph.*, p.name AS product_name FROM price_history ph LEFT JOIN products p ON ph.product_id = p.id WHERE DATE(ph.created_at) >= :from AND DATE(ph.created_at) <= :to';
$params = ['from' => $from, 'to' => $to];

if ($productId > 0) {
    $sql .= ' AND ph.product_id = :pid';
    $params['pid'] = $productId;
}

$sql .= ' ORDER BY ph.created_at DESC';
$rows = $pdo->prepare($sql);
$rows->execute($params);
$history = $rows->fetchAll();

$products = $pdo->query('SELECT id, name FROM products ORDER BY name')->fetchAll();
?>
<h2>Price Change History</h2>

<form method="GET" class="filter-form" style="margin-bottom:20px;">
    <input type="hidden" name="page" value="price_history">
    <label>Product:
        <select name="product_id">
            <option value="">All products</option>
            <?php foreach ($products as $p): ?>
                <option value="<?= $p['id'] ?>" <?= $productId === (int) $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>From: <input type="date" name="from" value="<?= htmlspecialchars($from) ?>"></label>
    <label>To: <input type="date" name="to" value="<?= htmlspecialchars($to) ?>"></label>
    <button type="submit" class="btn">Filter</button>
    <a href="?page=price_history" class="btn btn-secondary">Reset</a>
</form>

<div class="table-responsive">
<table class="table">
    <thead>
        <tr>
            <th>Date/Time</th>
            <th>Product</th>
            <th>Old Price</th>
            <th>New Price</th>
            <th>Change</th>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($history)): ?>
        <tr><td colspan="5">No price changes found.</td></tr>
    <?php else: ?>
        <?php foreach ($history as $r): ?>
            <?php
                $old = (float) $r['old_price'];
                $new = (float) $r['new_price'];
                $diff = $new - $old;
                $diffClass = $diff > 0 ? 'text-danger' : ($diff < 0 ? 'text-success' : '');
                $diffSign = $diff > 0 ? '+' : '';
            ?>
            <tr>
                <td><?= htmlspecialchars($r['created_at']) ?></td>
                <td><a href="?page=products&edit=<?= $r['product_id'] ?>"><?= htmlspecialchars($r['product_name'] ?? 'Deleted #'.$r['product_id']) ?></a></td>
                <td><?= number_format($old, 2) ?></td>
                <td><?= number_format($new, 2) ?></td>
                <td class="<?= $diffClass ?>" style="font-weight:700;"><?= $diffSign ?><?= number_format($diff, 2) ?></td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>
</div>
