<?php
requireAdmin();
$pdo = getPDO();
$messages = [];

$filterAgent = trim($_GET['agent'] ?? '');
$filterFrom = trim($_GET['date_from'] ?? '');
$filterTo = trim($_GET['date_to'] ?? '');
$filterStatus = trim($_GET['status'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay_commission'])) {
    $saleId = (int) ($_POST['sale_id'] ?? 0);
    $amount = (float) ($_POST['amount'] ?? 0);
    $notes = trim($_POST['notes'] ?? '');
    if ($saleId > 0 && $amount > 0) {
        $stmt = $pdo->prepare('UPDATE sales SET paid_at = NOW() WHERE id = :id AND paid_at IS NULL');
        $stmt->execute(['id' => $saleId]);
        if ($stmt->rowCount()) {
            $ins = $pdo->prepare('INSERT INTO commission_payments (sale_id, amount_paid, paid_at, notes) VALUES (:sid, :amt, NOW(), :notes)');
            $ins->execute(['sid' => $saleId, 'amt' => $amount, 'notes' => $notes ?: null]);
            $messages[] = ['type' => 'success', 'text' => 'Commission marked as paid.'];
        } else {
            $messages[] = ['type' => 'error', 'text' => 'Commission already paid or sale not found.'];
        }
    }
}

$where = ['s.commission_amount IS NOT NULL'];
$params = [];
if ($filterAgent !== '') {
    $where[] = 's.agent_name LIKE :agent';
    $params['agent'] = '%' . $filterAgent . '%';
}
if ($filterFrom !== '') {
    $where[] = 's.sale_date >= :from';
    $params['from'] = $filterFrom;
}
if ($filterTo !== '') {
    $where[] = 's.sale_date <= :to';
    $params['to'] = $filterTo;
}
if ($filterStatus === 'paid') {
    $where[] = 's.paid_at IS NOT NULL';
} elseif ($filterStatus === 'pending') {
    $where[] = 's.paid_at IS NULL';
}

$sql = 'SELECT s.id, s.sale_date, s.total_amount, s.agent_name, s.commission_percent, s.commission_amount, s.paid_at, c.name AS customer_name FROM sales s LEFT JOIN customers c ON s.customer_id = c.id WHERE ' . implode(' AND ', $where) . ' ORDER BY s.sale_date DESC';
$commissions = $pdo->prepare($sql);
$commissions->execute($params);
$rows = $commissions->fetchAll();

$agg = $pdo->query("SELECT COUNT(*) AS total, COALESCE(SUM(commission_amount),0) AS total_amt, SUM(CASE WHEN paid_at IS NULL THEN commission_amount ELSE 0 END) AS pending_amt FROM sales WHERE commission_amount IS NOT NULL")->fetch();
$paymentHistory = $pdo->query("SELECT cp.*, s.agent_name, s.sale_date, c.name AS customer_name FROM commission_payments cp JOIN sales s ON cp.sale_id = s.id LEFT JOIN customers c ON s.customer_id = c.id ORDER BY cp.paid_at DESC LIMIT 20")->fetchAll();
?>
<section>
    <h1>Sales Commissions</h1>
    <?php foreach ($messages as $m): ?>
        <div class="alert alert-<?= $m['type'] ?>"><?= htmlspecialchars($m['text']) ?></div>
    <?php endforeach; ?>

    <div class="grid cards cards-3">
        <div class="card"><h2>Total commissions</h2><p><?= fmt((float) $agg['total_amt']) ?></p></div>
        <div class="card" style="border-top-color:var(--red-600)"><h2>Pending payment</h2><p><?= fmt((float) $agg['pending_amt']) ?></p></div>
        <div class="card" style="border-top-color:var(--brown-600)"><h2>Paid</h2><p><?= fmt((float) $agg['total_amt'] - (float) $agg['pending_amt']) ?></p></div>
    </div>

    <div class="panel">
        <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;">
            <input type="hidden" name="page" value="commissions">
            <input type="text" name="agent" placeholder="Agent name" value="<?= htmlspecialchars($filterAgent) ?>" style="flex:1;min-width:140px;margin:0">
            <input type="date" name="date_from" value="<?= htmlspecialchars($filterFrom) ?>" style="margin:0">
            <input type="date" name="date_to" value="<?= htmlspecialchars($filterTo) ?>" style="margin:0">
            <select name="status" style="margin:0">
                <option value="">All</option>
                <option value="pending"<?= $filterStatus === 'pending' ? ' selected' : '' ?>>Pending</option>
                <option value="paid"<?= $filterStatus === 'paid' ? ' selected' : '' ?>>Paid</option>
            </select>
            <button type="submit" style="margin:0">Filter</button>
            <?php if ($filterAgent !== '' || $filterFrom !== '' || $filterTo !== '' || $filterStatus !== ''): ?>
                <a href="?page=commissions" style="display:inline-flex;align-items:center;padding:0 12px;color:var(--brown-800);font-weight:600">Clear</a>
            <?php endif; ?>
        </form>

        <table>
            <thead><tr><th>Sale</th><th>Date</th><th>Customer</th><th>Total</th><th>Agent</th><th>Rate</th><th>Commission</th><th>Status</th><th></th></tr></thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="9">No commissions found.</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td>#<?= $r['id'] ?></td>
                            <td><?= htmlspecialchars($r['sale_date']) ?></td>
                            <td><?= htmlspecialchars($r['customer_name'] ?? 'Unknown') ?></td>
                            <td><?= fmt((float) $r['total_amount']) ?></td>
                            <td><?= htmlspecialchars($r['agent_name'] ?? '-') ?></td>
                            <td><?= $r['commission_percent'] ? (float) $r['commission_percent'] . '%' : '-' ?></td>
                            <td><?= fmt((float) $r['commission_amount']) ?></td>
                            <td><?= $r['paid_at'] ? '<span style="color:var(--brown-600);font-weight:700">Paid ' . htmlspecialchars(date('M j', strtotime($r['paid_at']))) . '</span>' : '<span style="color:var(--red-600);font-weight:600">Pending</span>' ?></td>
                            <td>
                                <?php if (!$r['paid_at']): ?>
                                <form method="post" style="display:inline" onsubmit="return confirm('Mark commission as paid?')">
                                    <input type="hidden" name="sale_id" value="<?= $r['id'] ?>">
                                    <input type="hidden" name="amount" value="<?= (float) $r['commission_amount'] ?>">
                                    <input type="text" name="notes" placeholder="Notes (optional)" style="width:120px;margin:0;font-size:0.8rem">
                                    <button type="submit" name="pay_commission" style="font-size:0.8rem;padding:2px 8px">Pay</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if (!empty($paymentHistory)): ?>
    <div class="panel" style="border-top-color:var(--brown-600)">
        <h2>Payment History</h2>
        <table>
            <thead><tr><th>Date</th><th>Sale</th><th>Customer</th><th>Agent</th><th>Amount</th><th>Notes</th></tr></thead>
            <tbody>
                <?php foreach ($paymentHistory as $ph): ?>
                    <tr>
                        <td><?= htmlspecialchars(date('M j, Y', strtotime($ph['paid_at']))) ?></td>
                        <td>#<?= $ph['sale_id'] ?></td>
                        <td><?= htmlspecialchars($ph['customer_name'] ?? 'Unknown') ?></td>
                        <td><?= htmlspecialchars($ph['agent_name'] ?? '-') ?></td>
                        <td style="font-weight:700;color:var(--brown-600)"><?= fmt((float) $ph['amount_paid']) ?></td>
                        <td><?= htmlspecialchars($ph['notes'] ?? '-') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</section>
