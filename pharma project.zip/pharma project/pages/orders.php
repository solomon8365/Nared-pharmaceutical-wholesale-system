<?php
requireAdmin();
require_once __DIR__ . '/../includes/stock_helper.php';
$pdo = getPDO();
$messages = [];
$products = $pdo->query('SELECT id, name, price FROM products ORDER BY name')->fetchAll();
$suppliers = $pdo->query('SELECT id, name FROM suppliers ORDER BY name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['record_payment'])) {
    $payOrderId = (int) ($_POST['pay_order_id'] ?? 0);
    $amount = (float) ($_POST['pay_amount'] ?? 0);
    $payDate = $_POST['pay_date'] ?? date('Y-m-d');
    $payMethod = trim($_POST['pay_method'] ?? '');
    $payRef = trim($_POST['pay_reference'] ?? '');
    $payNotes = trim($_POST['pay_notes'] ?? '');

    if ($payOrderId <= 0 || $amount <= 0) {
        $messages[] = ['type' => 'error', 'text' => 'Valid order and payment amount are required.'];
    } else {
        $pdo->prepare('INSERT INTO supplier_payments (order_id, amount_paid, payment_date, payment_method, reference, notes, created_at) VALUES (:oid, :amt, :dt, :m, :r, :n, NOW())')
            ->execute(['oid' => $payOrderId, 'amt' => $amount, 'dt' => $payDate, 'm' => $payMethod, 'r' => $payRef, 'n' => $payNotes]);
        $messages[] = ['type' => 'success', 'text' => 'Payment of ' . fmt($amount) . ' recorded for order #' . $payOrderId . '.'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['record_payment'])) {
    $supplierId = (int) ($_POST['supplier_id'] ?? 0);
    $orderDate = $_POST['order_date'] ?? date('Y-m-d');
    $items = $_POST['items'] ?? [];

    if ($supplierId <= 0 || empty($items)) {
        $messages[] = ['type' => 'error', 'text' => 'Supplier and at least one order item are required.'];
    } else {
        $pdo->beginTransaction();
        try {
            $total = 0;
            foreach ($items as $item) {
                $productId = (int) ($item['product_id'] ?? 0);
                $quantity = (int) ($item['quantity'] ?? 0);
                if ($productId <= 0 || $quantity <= 0) {
                    continue;
                }
                $stmt = $pdo->prepare('SELECT price FROM products WHERE id = :id');
                $stmt->execute(['id' => $productId]);
                $price = $stmt->fetchColumn();
                $total += $price * $quantity;
            }

            $stmt = $pdo->prepare('INSERT INTO orders (supplier_id, order_date, total_amount, created_at) VALUES (:supplier, :order_date, :total, NOW())');
            $stmt->execute(['supplier' => $supplierId, 'order_date' => $orderDate, 'total' => $total]);
            $orderId = $pdo->lastInsertId();

            $insertItem = $pdo->prepare('INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (:order_id, :product_id, :quantity, :unit_price)');
            $insertBatch = $pdo->prepare('INSERT INTO product_batches (product_id, batch_number, expiry_date, quantity, purchase_price) VALUES (:product_id, :batch_number, :expiry_date, :quantity, :purchase_price)');
            foreach ($items as $item) {
                $productId = (int) ($item['product_id'] ?? 0);
                $quantity = (int) ($item['quantity'] ?? 0);
                if ($productId <= 0 || $quantity <= 0) {
                    continue;
                }
                $stmt = $pdo->prepare('SELECT price FROM products WHERE id = :id');
                $stmt->execute(['id' => $productId]);
                $price = $stmt->fetchColumn();
                $insertItem->execute(['order_id' => $orderId, 'product_id' => $productId, 'quantity' => $quantity, 'unit_price' => $price]);
                $pdo->prepare('UPDATE products SET stock_quantity = stock_quantity + :qty WHERE id = :id')->execute(['qty' => $quantity, 'id' => $productId]);
                log_stock_movement($pdo, $productId, $quantity, 'Supplier order restock', 'order', (int) $orderId);

                $batchNumber = trim($item['batch_number'] ?? '');
                $expiryDate = trim($item['expiry_date'] ?? '');
                $purchasePrice = (float) ($item['purchase_price'] ?? 0);
                if ($batchNumber !== '' && $expiryDate !== '') {
                    $insertBatch->execute([
                        'product_id' => $productId,
                        'batch_number' => $batchNumber,
                        'expiry_date' => $expiryDate,
                        'quantity' => $quantity,
                        'purchase_price' => $purchasePrice > 0 ? $purchasePrice : $price,
                    ]);
                }
            }

            $pdo->commit();
            $messages[] = ['type' => 'success', 'text' => 'Order created successfully.'];
        } catch (Exception $e) {
            $pdo->rollBack();
            $messages[] = ['type' => 'error', 'text' => 'Failed to create order: ' . $e->getMessage()];
        }
    }
}

$filterSupplier = (int) ($_GET['supplier_id'] ?? 0);
$filterDateFrom = trim($_GET['date_from'] ?? '');
$filterDateTo = trim($_GET['date_to'] ?? '');
$where = [];
$params = [];
if ($filterSupplier > 0) {
    $where[] = 'o.supplier_id = :supplier';
    $params['supplier'] = $filterSupplier;
}
if ($filterDateFrom !== '') {
    $where[] = 'o.order_date >= :date_from';
    $params['date_from'] = $filterDateFrom;
}
if ($filterDateTo !== '') {
    $where[] = 'o.order_date <= :date_to';
    $params['date_to'] = $filterDateTo;
}
$sql = 'SELECT o.id, o.order_date, o.total_amount, s.name AS supplier_name, COALESCE(sp.paid, 0) AS paid FROM orders o LEFT JOIN suppliers s ON o.supplier_id = s.id LEFT JOIN (SELECT order_id, SUM(amount_paid) AS paid FROM supplier_payments GROUP BY order_id) sp ON sp.order_id = o.id';
if (!empty($where)) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY o.created_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();
?>
<section>
    <h1>Supplier orders</h1>
    <?php foreach ($messages as $message): ?>
        <div class="alert alert-<?= htmlspecialchars($message['type']) ?>"><?= htmlspecialchars($message['text']) ?></div>
    <?php endforeach; ?>

    <div class="panel split">
        <div class="panel-block">
            <h2>Create Order</h2>
            <form method="post" class="form-grid" id="order-form">
                <label>Supplier
                    <select name="supplier_id" required>
                        <option value="">Select supplier</option>
                        <?php foreach ($suppliers as $supplier): ?>
                            <option value="<?= htmlspecialchars($supplier['id']) ?>"><?= htmlspecialchars($supplier['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Order date<input type="date" name="order_date" value="<?= date('Y-m-d') ?>"></label>
                <div class="order-items" id="order-items">
                    <div class="order-item-row">
                        <select name="items[0][product_id]" required>
                            <option value="">Select product</option>
                            <?php foreach ($products as $product): ?>
                                <option value="<?= htmlspecialchars($product['id']) ?>"><?= htmlspecialchars($product['name']) ?> - <?= number_format($product['price'], 2) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="number" name="items[0][quantity]" value="1" min="1" required>
                        <input type="text" name="items[0][batch_number]" placeholder="Batch #" style="min-width:90px">
                        <input type="date" name="items[0][expiry_date]" style="min-width:130px">
                        <input type="number" step="0.01" name="items[0][purchase_price]" placeholder="Cost" style="min-width:90px">
                        <button type="button" class="remove-item">Remove</button>
                    </div>
                </div>
                <button type="button" id="add-order-item">Add Item</button>
                <button type="submit">Save Order</button>
            </form>
        </div>

        <div class="panel-block">
            <h2>Order History</h2>
            <form method="get" style="margin-bottom:12px;display:flex;gap:8px;flex-wrap:wrap">
                <input type="hidden" name="page" value="orders">
                <select name="supplier_id" style="flex:1;min-width:140px;margin:0">
                    <option value="">All suppliers</option>
                    <?php foreach ($suppliers as $sup): ?>
                        <option value="<?= htmlspecialchars($sup['id']) ?>"<?= $filterSupplier === (int) $sup['id'] ? ' selected' : '' ?>><?= htmlspecialchars($sup['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="date" name="date_from" value="<?= htmlspecialchars($filterDateFrom) ?>" style="margin:0" placeholder="From">
                <input type="date" name="date_to" value="<?= htmlspecialchars($filterDateTo) ?>" style="margin:0" placeholder="To">
                <button type="submit" style="margin:0">Filter</button>
                <?php if ($filterSupplier > 0 || $filterDateFrom !== '' || $filterDateTo !== ''): ?><a href="?page=orders" style="display:inline-flex;align-items:center;padding:0 12px;color:var(--brown-800);font-weight:600">Clear</a><?php endif; ?>
            </form>
            <table>
                <thead><tr><th>ID</th><th>Date</th><th>Supplier</th><th>Total</th><th>Paid</th><th>Balance</th><th></th></tr></thead>
                <tbody>
                    <?php if (empty($orders)): ?>
                        <tr><td colspan="7">No orders recorded yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($orders as $order): ?>
                            <?php
                            $total = (float) $order['total_amount'];
                            $paid = (float) $order['paid'];
                            $balance = $total - $paid;
                            $balClass = $balance <= 0 ? 'text-success' : 'text-danger';
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($order['id']) ?></td>
                                <td><?= htmlspecialchars($order['order_date']) ?></td>
                                <td><?= htmlspecialchars($order['supplier_name'] ?? 'Unknown') ?></td>
                                <td><?= fmt($total) ?></td>
                                <td><?= fmt($paid) ?></td>
                                <td class="<?= $balClass ?>" style="font-weight:700"><?= fmt($balance) ?></td>
                                <td>
                                    <button class="btn btn-secondary" style="padding:3px 8px;font-size:0.78rem" onclick="togglePayForm(<?= (int) $order['id'] ?>)">Pay</button>
                                    <div id="pay-form-<?= (int) $order['id'] ?>" style="display:none;margin-top:6px;border-top:1px solid var(--neutral-200);padding-top:6px;">
                                        <form method="post" style="font-size:0.82rem">
                                            <input type="hidden" name="record_payment" value="1">
                                            <input type="hidden" name="pay_order_id" value="<?= (int) $order['id'] ?>">
                                            <label style="display:block;margin:2px 0">Amount<input type="number" step="0.01" name="pay_amount" required style="width:90px;font-size:0.82rem;padding:3px 6px"></label>
                                            <label style="display:block;margin:2px 0">Date<input type="date" name="pay_date" value="<?= date('Y-m-d') ?>" style="width:auto;font-size:0.82rem;padding:3px 6px"></label>
                                            <label style="display:block;margin:2px 0">Method<input type="text" name="pay_method" placeholder="Bank/Cheque/Cash" style="width:100px;font-size:0.82rem;padding:3px 6px"></label>
                                            <label style="display:block;margin:2px 0">Ref#<input type="text" name="pay_reference" placeholder="Optional" style="width:100px;font-size:0.82rem;padding:3px 6px"></label>
                                            <label style="display:block;margin:2px 0">Notes<input type="text" name="pay_notes" placeholder="Optional" style="width:100px;font-size:0.82rem;padding:3px 6px"></label>
                                            <button type="submit" style="font-size:0.78rem;padding:3px 8px;margin-top:4px">Record</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<script>
function togglePayForm(id) {
    var el = document.getElementById('pay-form-' + id);
    if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
</script>
