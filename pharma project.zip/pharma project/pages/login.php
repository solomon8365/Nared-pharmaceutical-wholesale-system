<?php
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
if (currentUser()) {
    header('Location: index.php?page=dashboard');
    exit;
}

$preserveRedirect = '';
$preserveProductId = 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $preserveRedirect = ($_POST['after_login'] ?? '') === 'place_order' ? 'place_order' : '';
    $preserveProductId = (int) ($_POST['product_id'] ?? 0);
} else {
    $preserveRedirect = ($_GET['redirect'] ?? '') === 'place_order' ? 'place_order' : '';
    $preserveProductId = (int) ($_GET['product_id'] ?? 0);
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        $errors[] = 'Username and password are required.';
    } else {
        $code = loginForPortal($username, $password, null);
        if ($code === 'invalid_credentials') {
            $errors[] = 'Invalid username or password.';
        } else {
            if (isCustomer() && $preserveRedirect === 'place_order') {
                $url = 'index.php?page=place_order';
                if ($preserveProductId > 0) {
                    $url .= '&product_id=' . $preserveProductId;
                }
                header('Location: ' . $url);
                exit;
            }
            header('Location: index.php?page=dashboard');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
    <style>
        .login-page { background: radial-gradient(ellipse at 15% 30%, rgba(139,94,60,0.15) 0%, transparent 50%), radial-gradient(ellipse at 85% 70%, rgba(220,38,38,0.1) 0%, transparent 50%), linear-gradient(160deg,#f7f2ec 0%,#fef2f2 100%) !important; }
        .login-card-head { background:linear-gradient(160deg,#2c1810,#4a2c1a 50%,#5c3a24); padding:36px 32px 28px; text-align:center; position:relative; overflow:hidden; }
        .login-card-head .login-card-logo > div > div:first-child { position:relative; width:50px; height:50px; border:2.5px solid rgba(255,255,255,0.3); border-radius:50%; flex-shrink:0; }
        .login-card-head .login-card-logo > div > div:first-child > div { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); background:#fff; border-radius:2px; }
        .login-card-head .login-card-logo > div > div:first-child > div:first-child { width:28px; height:4px; }
        .login-card-head .login-card-logo > div > div:first-child > div:last-child { width:4px; height:28px; }
    </style>
</head>
<body>
<div class="login-page">
    <div class="login-card">
        <div class="login-card-head">
            <div class="login-card-logo" style="display:flex;justify-content:center;margin-bottom:14px;">
                <div style="display:flex;align-items:center;gap:14px;">
                    <div style="position:relative;width:50px;height:50px;border:2.5px solid rgba(255,255,255,0.3);border-radius:50%;flex-shrink:0;">
                        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:28px;height:4px;background:#fff;border-radius:2px;"></div>
                        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:4px;height:28px;background:#fff;border-radius:2px;"></div>
                    </div>
                    <div style="display:flex;flex-direction:column;text-align:left;">
                        <span style="font-size:1.6rem;font-weight:900;color:#00a35e;letter-spacing:5px;line-height:1.15;">NARED</span>
                        <span style="font-size:0.65rem;font-weight:600;color:#006838;letter-spacing:3.5px;line-height:1.2;">GENERAL TRADING PLC</span>
                    </div>
                </div>
            </div>
            <p style="color:#00a35e;font-weight:700"><?= htmlspecialchars(APP_NAME) ?></p>
        </div>
        <div class="login-card-body">
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error"><?= htmlspecialchars(implode(' ', $errors)) ?></div>
            <?php endif; ?>
            <form method="post" action="index.php?page=login">
                <input type="hidden" name="after_login" value="<?= htmlspecialchars($preserveRedirect) ?>">
                <input type="hidden" name="product_id" value="<?= $preserveProductId > 0 ? htmlspecialchars((string) $preserveProductId) : '' ?>">
                <div class="login-field">
                    <label for="username">Username</label>
                    <div class="login-input-wrap">
                        <svg class="login-input-icon" viewBox="0 0 20 20" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
                            <circle cx="10" cy="7" r="4"/>
                            <path d="M3 18c0-4 3.1-7 7-7s7 3 7 7"/>
                        </svg>
                        <input type="text" id="username" name="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required autocomplete="username" placeholder="Enter your username">
                    </div>
                </div>
                <div class="login-field">
                    <label for="password">Password</label>
                    <div class="login-input-wrap">
                        <svg class="login-input-icon" viewBox="0 0 20 20" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
                            <rect x="3" y="9" width="14" height="9" rx="2"/>
                            <path d="M7 9V6a3 3 0 0 1 6 0v3"/>
                            <circle cx="10" cy="14" r="1.2" fill="currentColor" stroke="none"/>
                        </svg>
                        <input type="password" id="password" name="password" required autocomplete="current-password" placeholder="Enter your password">
                    </div>
                    <label class="pw-toggle"><input type="checkbox"> Show password</label>
                </div>
                <button type="submit" style="background:linear-gradient(180deg,#00a35e,#006838);border:1px solid #004d2b">Sign in</button>
            </form>
            <div class="login-card-footer">
                <a href="index.php?page=register">New customer? Register</a>
                <span class="login-card-sep">·</span>
                <a href="index.php?page=catalog">Browse products</a>
            </div>
        </div>
    </div>
</div>
<script>
document.querySelector('form').addEventListener('submit', function(e) {
    var u = this.querySelector('[name="username"]');
    var p = this.querySelector('[name="password"]');
    var valid = true;
    [u, p].forEach(function(el) {
        el.classList.remove('error');
        var err = el.parentNode.querySelector('.field-error');
        if (err) err.style.display = 'none';
    });
    if (u.value.trim() === '') { u.classList.add('error'); valid = false; }
    if (p.value.trim() === '') { p.classList.add('error'); valid = false; }
    if (!valid) e.preventDefault();
    else this.querySelector('button[type="submit"]').classList.add('loading');
});
document.querySelectorAll('.pw-toggle input[type="checkbox"]').forEach(function(cb) {
    cb.addEventListener('change', function() {
        var p = this.closest('form').querySelector('[name="password"]');
        if (p) p.type = this.checked ? 'text' : 'password';
    });
});
</script>
</body>
</html>
