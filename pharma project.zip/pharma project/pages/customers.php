<?php
requireAdmin();
$pdo = getPDO();
$messages = [];

$editCustomer = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM customers WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => (int) $_GET['edit']]);
    $editCustomer = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['_action'] ?? '';

    if ($action === 'delete') {
        $deleteId = (int) ($_POST['delete_id'] ?? 0);
        if ($deleteId > 0) {
            try {
                $pdo->prepare('DELETE FROM customers WHERE id = :id')->execute(['id' => $deleteId]);
                $messages[] = ['type' => 'success', 'text' => 'Customer deleted successfully.'];
            } catch (Throwable $e) {
                $messages[] = ['type' => 'error', 'text' => 'Could not delete customer: ' . $e->getMessage()];
            }
        }
    } elseif ($action === 'update') {
        $customerId = (int) ($_POST['customer_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $contact = trim($_POST['contact'] ?? '');
        $phone = trim($_POST['phone'] ?? '');

        if ($customerId <= 0 || $name === '') {
            $messages[] = ['type' => 'error', 'text' => 'Customer name is required.'];
        } else {
            $stmt = $pdo->prepare('UPDATE customers SET name = :name, contact_person = :contact, phone = :phone WHERE id = :id');
            $stmt->execute(['name' => $name, 'contact' => $contact, 'phone' => $phone, 'id' => $customerId]);
            $messages[] = ['type' => 'success', 'text' => 'Customer updated successfully.'];
        }
    } elseif (isset($_POST['create_customer_login'])) {
        $linkCustomerId = (int) ($_POST['link_customer_id'] ?? 0);
        $newUsername = trim($_POST['new_username'] ?? '');
        $newPassword = $_POST['new_password'] ?? '';

        if ($linkCustomerId <= 0 || $newUsername === '' || strlen($newPassword) < 6) {
            $messages[] = ['type' => 'error', 'text' => 'Customer, username, and password (min 6 characters) are required.'];
        } else {
            $cstmt = $pdo->prepare('SELECT name FROM customers WHERE id = :id LIMIT 1');
            $cstmt->execute(['id' => $linkCustomerId]);
            $cname = $cstmt->fetchColumn();
            if ($cname === false) {
                $messages[] = ['type' => 'error', 'text' => 'Customer not found.'];
            } else {
                try {
                    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare('INSERT INTO users (username, password, full_name, role, customer_id, created_at) VALUES (:u, :p, :fn, \'customer\', :cid, NOW())');
                    $stmt->execute([
                        'u' => $newUsername,
                        'p' => $hash,
                        'fn' => (string) $cname,
                        'cid' => $linkCustomerId,
                    ]);
                    $messages[] = ['type' => 'success', 'text' => 'Customer portal login created. They can sign in with that username.'];
                } catch (PDOException $e) {
                    if (($e->errorInfo[1] ?? 0) === 1062) {
                        $messages[] = ['type' => 'error', 'text' => 'Username is already taken.'];
                    } else {
                        $messages[] = ['type' => 'error', 'text' => 'Could not create login: ' . $e->getMessage()];
                    }
                }
            }
        }
    } else {
        $name = trim($_POST['name'] ?? '');
        $contact = trim($_POST['contact'] ?? '');
        $phone = trim($_POST['phone'] ?? '');

        if ($name === '') {
            $messages[] = ['type' => 'error', 'text' => 'Customer name is required.'];
        } else {
            $stmt = $pdo->prepare('INSERT INTO customers (name, contact_person, phone, created_at) VALUES (:name, :contact, :phone, NOW())');
            $stmt->execute(['name' => $name, 'contact' => $contact, 'phone' => $phone]);
            $messages[] = ['type' => 'success', 'text' => 'Customer added successfully.'];
        }
    }
}

$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare("SELECT c.*, (SELECT u.id FROM users u WHERE u.customer_id = c.id AND u.role = 'customer' LIMIT 1) AS portal_user_id, (SELECT u.username FROM users u WHERE u.customer_id = c.id AND u.role = 'customer' LIMIT 1) AS portal_username FROM customers c WHERE c.name LIKE :q OR c.contact_person LIKE :q OR c.phone LIKE :q ORDER BY c.created_at DESC");
    $stmt->execute(['q' => "%$search%"]);
    $customers = $stmt->fetchAll();
} else {
    $customers = $pdo->query("SELECT c.*, (SELECT u.id FROM users u WHERE u.customer_id = c.id AND u.role = 'customer' LIMIT 1) AS portal_user_id, (SELECT u.username FROM users u WHERE u.customer_id = c.id AND u.role = 'customer' LIMIT 1) AS portal_username FROM customers c ORDER BY c.created_at DESC")->fetchAll();
}
?>
<section>
    <h1>Customers</h1>
    <?php foreach ($messages as $message): ?>
        <div class="alert alert-<?= htmlspecialchars($message['type']) ?>"><?= htmlspecialchars($message['text']) ?></div>
    <?php endforeach; ?>

    <?php if ($editCustomer): ?>
        <div class="panel" style="max-width:500px">
            <h2>Edit customer #<?= htmlspecialchars((string) $editCustomer['id']) ?></h2>
            <form method="post" class="form-grid">
                <input type="hidden" name="_action" value="update">
                <input type="hidden" name="customer_id" value="<?= htmlspecialchars((string) $editCustomer['id']) ?>">
                <label>Name<input type="text" name="name" value="<?= htmlspecialchars($editCustomer['name']) ?>" required></label>
                <label>Contact person<input type="text" name="contact" value="<?= htmlspecialchars((string) ($editCustomer['contact_person'] ?? '')) ?>"></label>
                <label>Phone<input type="text" name="phone" value="<?= htmlspecialchars((string) ($editCustomer['phone'] ?? '')) ?>"></label>
                <div>
                    <button type="submit">Update customer</button>
                    <a href="?page=customers" style="display:inline-block;padding:12px 20px;color:var(--brown-800);font-weight:700">Cancel</a>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <div class="panel split">
        <div class="panel-block">
            <h2>Add customer</h2>
            <form method="post" class="form-grid">
                <input type="hidden" name="_action" value="create">
                <label>Name<input type="text" name="name" required></label>
                <label>Contact person<input type="text" name="contact"></label>
                <label>Phone<input type="text" name="phone"></label>
                <button type="submit">Create customer</button>
            </form>
        </div>

        <div class="panel-block">
            <h2>Customer portal login</h2>
            <p class="hint">Customers can also <a href="index.php?page=register">register themselves</a> and order online. Create a login here if you prefer to set one up for them.</p>
            <form method="post" class="form-grid">
                <input type="hidden" name="create_customer_login" value="1">
                <label>Customer
                    <select name="link_customer_id" required>
                        <option value="">Select customer</option>
                        <?php foreach ($customers as $customer): ?>
                            <option value="<?= htmlspecialchars((string) $customer['id']) ?>"><?= htmlspecialchars($customer['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Username<input type="text" name="new_username" required autocomplete="off"></label>
                <label>Password<input type="password" name="new_password" required minlength="6" autocomplete="new-password"></label>
                <button type="submit">Create login</button>
            </form>
        </div>
    </div>

    <div class="panel">
        <h2>Customer list</h2>
        <form method="get" style="margin-bottom:12px;display:flex;gap:8px">
            <input type="hidden" name="page" value="customers">
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search customers..." style="flex:1;margin:0">
            <button type="submit" style="margin:0">Search</button>
            <?php if ($search !== ''): ?><a href="?page=customers" style="display:inline-flex;align-items:center;padding:0 12px;color:var(--brown-800);font-weight:600">Clear</a><?php endif; ?>
        </form>
        <table>
            <thead><tr><th>ID</th><th>Name</th><th>Contact</th><th>Phone</th><th>Portal user</th><th>Actions</th></tr></thead>
            <tbody>
                <?php if (empty($customers)): ?>
                    <tr><td colspan="6">No customers found.</td></tr>
                <?php else: ?>
                    <?php foreach ($customers as $customer): ?>
                        <tr>
                            <td><?= htmlspecialchars((string) $customer['id']) ?></td>
                            <td><?= htmlspecialchars($customer['name']) ?></td>
                            <td><?= htmlspecialchars((string) ($customer['contact_person'] ?? '')) ?></td>
                            <td><?= htmlspecialchars((string) ($customer['phone'] ?? '')) ?></td>
                            <td><?= $customer['portal_username'] ? htmlspecialchars((string) $customer['portal_username']) : '—' ?></td>
                            <td>
                                <a href="?page=customers&edit=<?= htmlspecialchars((string) $customer['id']) ?>" style="color:var(--brown-800);font-weight:700;text-decoration:none;margin-right:10px">Edit</a>
                                <form method="post" style="display:inline" onsubmit="return confirm('Delete this customer?')">
                                    <input type="hidden" name="_action" value="delete">
                                    <input type="hidden" name="delete_id" value="<?= htmlspecialchars((string) $customer['id']) ?>">
                                    <button type="submit" class="btn-danger" style="padding:4px 10px;font-size:0.82rem">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
