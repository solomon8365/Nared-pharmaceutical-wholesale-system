<?php
$pdo = getPDO();

if (isCustomer()) {
    $cid = customerAccountCustomerId();
    $pending = 0;
    $allCount = 0;
    $recent = [];
    if ($cid !== null) {
        $pstmt = $pdo->prepare("SELECT COUNT(*) FROM customer_orders WHERE customer_id = :cid AND status = 'pending'");
        $pstmt->execute(['cid' => $cid]);
        $pending = (int) $pstmt->fetchColumn();
        $cstmt = $pdo->prepare("SELECT COUNT(*) FROM customer_orders WHERE customer_id = :cid");
        $cstmt->execute(['cid' => $cid]);
        $allCount = (int) $cstmt->fetchColumn();
        $rstmt = $pdo->prepare('SELECT id, order_date, total_amount, status, created_at FROM customer_orders WHERE customer_id = :cid ORDER BY created_at DESC LIMIT 8');
        $rstmt->execute(['cid' => $cid]);
        $recent = $rstmt->fetchAll();
    }
    $user = currentUser();
    ?>
<section>
    <h1>Welcome<?= $user['full_name'] ? ', ' . htmlspecialchars($user['full_name']) : '' ?></h1>
    <div class="grid cards cards-3">
        <div class="card"><h2>Pending approvals</h2><p><?= $pending ?></p></div>
        <div class="card"><h2>Total orders</h2><p><?= $allCount ?></p></div>
        <div class="card"><h2>Recent orders</h2><p><?= count($recent) ?></p></div>
    </div>
    <?php if ($cid === null): ?>
        <div class="panel"><p class="hint">Your account is not linked to a customer profile. Ask your administrator to create a <strong>customer portal login</strong> tied to your company record.</p></div>
    <?php else: ?>
        <div class="panel">
            <h2>Quick actions</h2>
            <p><a href="index.php?page=catalog">Browse products</a> · <a href="index.php?page=place_order">Place a new order</a> · <a href="index.php?page=my_orders">View my orders</a></p>
        </div>
        <div class="panel">
            <h2>Recent orders</h2>
            <table>
                <thead><tr><th>ID</th><th>Date</th><th>Total</th><th>Status</th></tr></thead>
                <tbody>
                    <?php if (empty($recent)): ?>
                        <tr><td colspan="4">No orders yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($recent as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars((string) $row['id']) ?></td>
                                <td><?= htmlspecialchars($row['order_date']) ?></td>
                                <td><?= fmt((float) $row['total_amount']) ?></td>
                                <td><span class="status-badge status-<?= htmlspecialchars($row['status']) ?>"><?= htmlspecialchars($row['status']) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
    <?php
    return;
}

$countData = [
    'products' => $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn(),
    'suppliers' => $pdo->query('SELECT COUNT(*) FROM suppliers')->fetchColumn(),
    'orders' => $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
    'customers' => $pdo->query('SELECT COUNT(*) FROM customers')->fetchColumn(),
    'sales' => $pdo->query('SELECT COUNT(*) FROM sales')->fetchColumn(),
    'pending_customer_orders' => $pdo->query("SELECT COUNT(*) FROM customer_orders WHERE status = 'pending'")->fetchColumn(),
];

$totalDue = $pdo->query("SELECT COALESCE(SUM(o.total_amount - COALESCE(sp.paid, 0)), 0) FROM orders o LEFT JOIN (SELECT order_id, SUM(amount_paid) AS paid FROM supplier_payments GROUP BY order_id) sp ON o.id = sp.order_id WHERE o.total_amount > COALESCE(sp.paid, 0)")->fetchColumn();
$recentPayments = $pdo->query("SELECT sp.*, o.total_amount, s.name AS supplier_name FROM supplier_payments sp JOIN orders o ON sp.order_id = o.id LEFT JOIN suppliers s ON o.supplier_id = s.id ORDER BY sp.created_at DESC LIMIT 5")->fetchAll();
try { $pendingCommissions = $pdo->query("SELECT COALESCE(SUM(commission_amount),0) FROM sales WHERE paid_at IS NULL AND commission_amount IS NOT NULL")->fetchColumn(); } catch (Exception $e) { $pendingCommissions = 0; }

$dailySales = $pdo->query("
    SELECT MONTH(sale_date) AS m, DAY(sale_date) AS d, sale_date, COUNT(*) AS tx, SUM(total_amount) AS rev
    FROM sales
    WHERE YEAR(sale_date) = YEAR(CURDATE())
    GROUP BY sale_date
    ORDER BY sale_date
")->fetchAll();
$monthData = [];
foreach ($dailySales as $ds) {
    $m = (int)$ds['m'];
    if (!isset($monthData[$m])) $monthData[$m] = ['days' => [], 'tx' => 0, 'rev' => 0];
    $monthData[$m]['days'][] = $ds;
    $monthData[$m]['tx'] += (int)$ds['tx'];
    $monthData[$m]['rev'] += (float)$ds['rev'];
}

$topProducts = $pdo->query("
    SELECT p.name, SUM(si.quantity * si.unit_price) AS rev
    FROM sale_items si
    JOIN products p ON si.product_id = p.id
    GROUP BY si.product_id
    ORDER BY rev DESC
    LIMIT 5
")->fetchAll();

$recentOrders = $pdo->query('SELECT o.id, o.order_date, o.total_amount, s.name AS supplier_name FROM orders o LEFT JOIN suppliers s ON o.supplier_id = s.id ORDER BY o.order_date DESC LIMIT 5')->fetchAll();
$recentSales = $pdo->query('SELECT s.id, s.sale_date, s.total_amount, c.name AS customer_name FROM sales s LEFT JOIN customers c ON s.customer_id = c.id ORDER BY s.sale_date DESC LIMIT 5')->fetchAll();

$recentMovements = $pdo->query("
    SELECT sm.*, p.name AS product_name
    FROM stock_movements sm
    LEFT JOIN products p ON sm.product_id = p.id
    ORDER BY sm.created_at DESC
    LIMIT 8
")->fetchAll();
?>
<section>
    <h1>Dashboard</h1>
    <div class="grid cards cards-7">
        <div class="card"><h2>Products</h2><p><?= $countData['products'] ?></p></div>
        <div class="card"><h2>Suppliers</h2><p><?= $countData['suppliers'] ?></p></div>
        <div class="card"><h2>Orders</h2><p><?= $countData['orders'] ?></p></div>
        <div class="card"><h2>Customers</h2><p><?= $countData['customers'] ?></p></div>
        <div class="card"><h2>Sales</h2><p><?= $countData['sales'] ?></p></div>
        <div class="card" style="border-top-color:var(--red-600)"><h2>Due to suppliers</h2><p><?= fmt((float) $totalDue) ?></p></div>
        <div class="card" style="border-top-color:var(--red-600)"><h2>Pending commissions</h2><p><?= fmt((float) $pendingCommissions) ?></p></div>
    </div>

    <div class="panel">
        <h2>Pending customer orders</h2>
        <p><strong><?= htmlspecialchars((string) $countData['pending_customer_orders']) ?></strong> awaiting approval.
            <a href="index.php?page=customer_order_queue">Open queue</a></p>
    </div>

    <div class="panel" id="monthly-sales-tabs">
        <h2>Monthly sales report (<?= date('Y') ?>)</h2>
        <div class="tabs">
            <?php for ($i = 1; $i <= 12; $i++):
                $label = date('M', mktime(0,0,0,$i,1));
                $active = $i === (int)date('m') ? ' active' : '';
                $hasData = isset($monthData[$i]);
            ?>
            <button class="tab-btn<?= $active ?>" data-month="<?= $i ?>"><?= $label ?><?= $hasData ? ' ✓' : '' ?></button>
            <?php endfor; ?>
        </div>
        <?php for ($i = 1; $i <= 12; $i++):
            $rev = $monthData[$i]['rev'] ?? 0;
            $tx = $monthData[$i]['tx'] ?? 0;
            $display = $i === (int)date('m') ? 'block' : 'none';
        ?>
        <div class="tab-content" id="tab-<?= $i ?>" style="display:<?= $display ?>">
            <div style="display:flex;gap:16px;margin-bottom:12px;">
                <span><strong>Revenue:</strong> <?= $rev > 0 ? fmt($rev) : '-' ?></span>
                <span><strong>Transactions:</strong> <?= $tx ?: '-' ?></span>
            </div>
            <?php if (!empty($monthData[$i]['days'])): ?>
            <table>
                <thead><tr><th>Date</th><th>Sales</th><th>Revenue</th></tr></thead>
                <tbody>
                    <?php foreach ($monthData[$i]['days'] as $day): ?>
                    <tr>
                        <td><?= htmlspecialchars($day['sale_date']) ?></td>
                        <td><?= (int)$day['tx'] ?></td>
                        <td><?= fmt((float)$day['rev']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="hint">No sales this month.</p>
            <?php endif; ?>
        </div>
        <?php endfor; ?>
    </div>

    <script>
    document.querySelectorAll('.tab-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
            this.classList.add('active');
            document.querySelectorAll('.tab-content').forEach(function(c) { c.style.display = 'none'; });
            document.getElementById('tab-' + this.getAttribute('data-month')).style.display = 'block';
        });
    });
    </script>

    <?php if (!empty($topProducts)): ?>
    <div class="panel">
        <h2>Top products</h2>
        <table>
            <thead><tr><th>Product</th><th>Revenue</th><th>Share</th></tr></thead>
            <tbody>
                <?php $grandProdRev = array_sum(array_column($topProducts, 'rev')); ?>
                <?php foreach ($topProducts as $tp): ?>
                    <?php $share = $grandProdRev > 0 ? round((float)$tp['rev'] / $grandProdRev * 100, 1) : 0; ?>
                    <tr>
                        <td><?= htmlspecialchars($tp['name']) ?></td>
                        <td><?= fmt((float) $tp['rev']) ?></td>
                        <td><?= $share ?>%</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <?php
    $expiringBatches = $pdo->query("SELECT pb.id, pb.batch_number, pb.expiry_date, pb.quantity, p.name AS product_name FROM product_batches pb JOIN products p ON pb.product_id = p.id WHERE pb.quantity > 0 AND pb.expiry_date <= DATE_ADD(CURDATE(), INTERVAL 90 DAY) ORDER BY pb.expiry_date ASC LIMIT 10")->fetchAll();
    $lowStockProducts = $pdo->query("SELECT id, name, stock_quantity FROM products WHERE stock_quantity > 0 AND stock_quantity <= 10 ORDER BY stock_quantity ASC LIMIT 10")->fetchAll();
    ?>
    <div style="display:flex;gap:20px;flex-wrap:wrap;">
        <?php if (!empty($expiringBatches)): ?>
        <div class="panel" style="flex:1;min-width:280px;border-top-color:var(--red-600)">
            <h2>⚠ Expiring batches (90 days)</h2>
            <table>
                <thead><tr><th>Product</th><th>Batch</th><th>Expiry</th><th>Qty</th></tr></thead>
                <tbody>
                    <?php foreach ($expiringBatches as $eb): ?>
                        <tr>
                            <td><?= htmlspecialchars($eb['product_name']) ?></td>
                            <td><?= htmlspecialchars($eb['batch_number']) ?></td>
                            <td style="<?= strtotime($eb['expiry_date']) <= time() ? 'color:var(--red-700);font-weight:700' : 'color:var(--red-600)' ?>"><?= htmlspecialchars($eb['expiry_date']) ?></td>
                            <td><?= htmlspecialchars((string) $eb['quantity']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
        <?php if (!empty($lowStockProducts)): ?>
        <div class="panel" style="flex:1;min-width:280px;border-top-color:var(--red-600)">
            <h2>⚠ Low stock (≤ 10)</h2>
            <table>
                <thead><tr><th>Product</th><th>Stock</th></tr></thead>
                <tbody>
                    <?php foreach ($lowStockProducts as $lp): ?>
                        <tr>
                            <td><?= htmlspecialchars($lp['name']) ?></td>
                            <td style="color:var(--red-700);font-weight:700"><?= htmlspecialchars((string) $lp['stock_quantity']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <div style="display:flex;gap:20px;flex-wrap:wrap;">
        <div class="panel" style="flex:1;min-width:280px;">
            <h2>Recent orders</h2>
            <table>
                <thead><tr><th>#</th><th>Date</th><th>Supplier</th><th>Total</th></tr></thead>
                <tbody>
                    <?php if (empty($recentOrders)): ?>
                        <tr><td colspan="4">No orders found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($recentOrders as $order): ?>
                            <tr>
                                <td><?= htmlspecialchars((string) $order['id']) ?></td>
                                <td><?= htmlspecialchars($order['order_date']) ?></td>
                                <td><?= htmlspecialchars($order['supplier_name'] ?? 'Unknown') ?></td>
                                <td><?= fmt((float) $order['total_amount']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="panel" style="flex:1;min-width:280px;">
            <h2>Recent sales</h2>
            <table>
                <thead><tr><th>#</th><th>Date</th><th>Customer</th><th>Total</th></tr></thead>
                <tbody>
                    <?php if (empty($recentSales)): ?>
                        <tr><td colspan="4">No sales found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($recentSales as $sale): ?>
                            <tr>
                                <td><?= htmlspecialchars((string) $sale['id']) ?></td>
                                <td><?= htmlspecialchars($sale['sale_date']) ?></td>
                                <td><?= htmlspecialchars($sale['customer_name'] ?? 'Unknown') ?></td>
                                <td><?= fmt((float) $sale['total_amount']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (!empty($recentPayments)): ?>
    <div class="panel" style="border-top-color:var(--brown-600)">
        <h2>Recent supplier payments</h2>
        <table>
            <thead><tr><th>Supplier</th><th>Amount</th><th>Date</th><th>Method</th><th>Reference</th></tr></thead>
            <tbody>
                <?php foreach ($recentPayments as $rp): ?>
                    <tr>
                        <td><?= htmlspecialchars($rp['supplier_name'] ?? 'Supplier #'.$rp['order_id']) ?></td>
                        <td><?= fmt((float) $rp['amount_paid']) ?></td>
                        <td><?= htmlspecialchars($rp['payment_date']) ?></td>
                        <td><?= htmlspecialchars($rp['payment_method'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($rp['reference'] ?? '-') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p style="margin-top:10px;"><a href="index.php?page=supplier_payments">View all payments →</a></p>
    </div>
    <?php endif; ?>

    <?php if (!empty($recentMovements)): ?>
    <div class="panel">
        <h2>Recent activity</h2>
        <div class="activity-feed">
            <?php foreach ($recentMovements as $m): ?>
                <?php
                    $qty = (int) $m['quantity_change'];
                    $cls = $qty >= 0 ? 'activity-in' : 'activity-out';
                    $icon = $qty >= 0 ? '&#x2191;' : '&#x2193;';
                ?>
                <div class="activity-item <?= $cls ?>">
                    <span class="activity-icon"><?= $icon ?></span>
                    <span class="activity-text">
                        <strong><?= htmlspecialchars($m['product_name'] ?? 'Deleted #'.$m['product_id']) ?></strong>
                        <?= $qty >= 0 ? '+' : '' ?><?= $qty ?> —
                        <?= htmlspecialchars($m['reason']) ?>
                        <?php if ($m['reference_type'] && $m['reference_id']): ?>
                            <em>(<?= htmlspecialchars($m['reference_type']) ?> #<?= $m['reference_id'] ?>)</em>
                        <?php endif; ?>
                    </span>
                    <span class="activity-time"><?= htmlspecialchars(date('M j, g:ia', strtotime($m['created_at']))) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
        <p style="margin-top:10px;"><a href="index.php?page=stock_movements">View full stock log →</a></p>
    </div>
    <?php endif; ?>
</section>
