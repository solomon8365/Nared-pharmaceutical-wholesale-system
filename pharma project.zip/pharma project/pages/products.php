<?php
requireAdmin();
require_once __DIR__ . '/../includes/product_upload.php';

$pdo = getPDO();
$messages = [];
$allCategories = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();

$editProduct = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => (int) $_GET['edit']]);
    $editProduct = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['_action'] ?? 'create';

    if ($action === 'delete') {
        $deleteId = (int) ($_POST['delete_id'] ?? 0);
        if ($deleteId > 0) {
            try {
                $pdo->prepare('DELETE FROM products WHERE id = :id')->execute(['id' => $deleteId]);
                $messages[] = ['type' => 'success', 'text' => 'Product deleted successfully.'];
            } catch (Throwable $e) {
                $messages[] = ['type' => 'error', 'text' => 'Could not delete product: ' . $e->getMessage()];
            }
        }
    } elseif ($action === 'update') {
        $productId = (int) ($_POST['product_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = (float) ($_POST['price'] ?? 0);
        $stock = (int) ($_POST['stock'] ?? 0);

        if ($productId <= 0 || $name === '' || $price <= 0) {
            $messages[] = ['type' => 'error', 'text' => 'Product name and price are required.'];
        } else {
            $old = $pdo->prepare('SELECT price FROM products WHERE id = :id');
            $old->execute(['id' => $productId]);
            $oldPrice = (float) ($old->fetchColumn() ?: 0);

            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare('UPDATE products SET name = :name, description = :description, category_id = :cat, price = :price, stock_quantity = :stock WHERE id = :id');
                $stmt->execute([
                    'name' => $name,
                    'description' => $description,
                    'cat' => !empty($_POST['category_id']) ? (int) $_POST['category_id'] : null,
                    'price' => $price,
                    'stock' => $stock,
                    'id' => $productId,
                ]);

                if (abs($oldPrice - $price) > 0.001) {
                    $uid = (int) ($_SESSION['user_id'] ?? 0);
                    $ph = $pdo->prepare('INSERT INTO price_history (product_id, old_price, new_price, changed_by, created_at) VALUES (:pid, :old, :new, :uid, NOW())');
                    $ph->execute(['pid' => $productId, 'old' => $oldPrice, 'new' => $price, 'uid' => $uid]);
                }

                $upload = $_FILES['image'] ?? null;
                if ($upload && (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                    $imagePath = store_product_image($upload, $productId);
                    if ($imagePath !== null) {
                        $pdo->prepare('UPDATE products SET image_path = :p WHERE id = :id')->execute(['p' => $imagePath, 'id' => $productId]);
                    }
                }

                $pdo->commit();
                $messages[] = ['type' => 'success', 'text' => 'Product updated successfully.'];
            } catch (Throwable $e) {
                $pdo->rollBack();
                $messages[] = ['type' => 'error', 'text' => $e->getMessage()];
            }
        }
    } else {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = (float) ($_POST['price'] ?? 0);
        $stock = (int) ($_POST['stock'] ?? 0);

        if ($name === '' || $price <= 0) {
            $messages[] = ['type' => 'error', 'text' => 'Product name and price are required.'];
        } else {
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare('INSERT INTO products (name, description, category_id, price, stock_quantity, created_at) VALUES (:name, :description, :cat, :price, :stock, NOW())');
                $stmt->execute([
                    'name' => $name,
                    'description' => $description,
                    'cat' => !empty($_POST['category_id']) ? (int) $_POST['category_id'] : null,
                    'price' => $price,
                    'stock' => $stock,
                ]);
                $newId = (int) $pdo->lastInsertId();

                $imagePath = null;
                $upload = $_FILES['image'] ?? null;
                if ($upload && (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                    $imagePath = store_product_image($upload, $newId);
                }
                if ($imagePath !== null) {
                    $pdo->prepare('UPDATE products SET image_path = :p WHERE id = :id')->execute(['p' => $imagePath, 'id' => $newId]);
                }

                $batchNo = trim($_POST['batch_number'] ?? '');
                $expiryDate = trim($_POST['expiry_date'] ?? '');
                $purchasePrice = (float) ($_POST['purchase_price'] ?? 0);
                if ($batchNo !== '' && $expiryDate !== '') {
                    $pb = $pdo->prepare('INSERT INTO product_batches (product_id, batch_number, expiry_date, quantity, purchase_price) VALUES (:pid, :bn, :exp, :qty, :pp)');
                    $pb->execute(['pid' => $newId, 'bn' => $batchNo, 'exp' => $expiryDate, 'qty' => $stock, 'pp' => $purchasePrice]);
                }

                $pdo->commit();
                $messages[] = ['type' => 'success', 'text' => 'Product added successfully.'];
            } catch (Throwable $e) {
                $pdo->rollBack();
                $messages[] = ['type' => 'error', 'text' => $e->getMessage()];
            }
        }
    }
}

$search = trim($_GET['search'] ?? '');
$catFilter = (int) ($_GET['category_id'] ?? 0);
$sql = 'SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id';
$conds = [];
$params = [];
if ($search !== '') {
    $conds[] = '(p.name LIKE :q OR p.description LIKE :q)';
    $params['q'] = "%$search%";
}
if ($catFilter > 0) {
    $conds[] = 'p.category_id = :cat';
    $params['cat'] = $catFilter;
}
if (!empty($conds)) {
    $sql .= ' WHERE ' . implode(' AND ', $conds);
}
$sql .= ' ORDER BY p.created_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$alertAll = $pdo->query("
    SELECT COUNT(*) AS total, SUM(CASE WHEN expiry_date < CURDATE() THEN 1 ELSE 0 END) AS expired,
        SUM(CASE WHEN expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN 1 ELSE 0 END) AS expiring
    FROM product_batches WHERE quantity > 0
")->fetch();
$alertBatches = $pdo->query("
    SELECT pb.id, pb.batch_number, pb.expiry_date, pb.quantity, p.name AS product_name, p.id AS product_id,
        DATEDIFF(pb.expiry_date, CURDATE()) AS days_left
    FROM product_batches pb
    JOIN products p ON pb.product_id = p.id
    WHERE pb.quantity > 0 AND pb.expiry_date <= DATE_ADD(CURDATE(), INTERVAL 90 DAY)
    ORDER BY pb.expiry_date ASC
    LIMIT 20
")->fetchAll();
$hasAlerts = ((int)$alertAll['expired'] + (int)$alertAll['expiring']) > 0;

$batchViewProductId = isset($_GET['batches']) ? (int) $_GET['batches'] : 0;
$batchViewProduct = null;
$batches = [];
if ($batchViewProductId > 0) {
    $bvStmt = $pdo->prepare('SELECT * FROM products WHERE id = :id LIMIT 1');
    $bvStmt->execute(['id' => $batchViewProductId]);
    $batchViewProduct = $bvStmt->fetch();
    if ($batchViewProduct) {
        $bStmt = $pdo->prepare('SELECT * FROM product_batches WHERE product_id = :pid ORDER BY expiry_date ASC');
        $bStmt->execute(['pid' => $batchViewProductId]);
        $batches = $bStmt->fetchAll();
    }
}
?>
<section>
    <h1>Products</h1>
    <?php foreach ($messages as $message): ?>
        <div class="alert alert-<?= htmlspecialchars($message['type']) ?>"><?= htmlspecialchars($message['text']) ?></div>
    <?php endforeach; ?>

    <div style="display:flex;gap:8px;align-items:center;margin-bottom:12px">
        <button onclick="var e=document.getElementById('expiry-panel');e.style.display=e.style.display==='none'?'block':'none'" style="background:<?= $hasAlerts ? '#dc2626' : 'var(--brown-600)' ?>;color:#fff;border:none;padding:6px 14px;border-radius:4px;cursor:pointer;font-weight:700;font-size:0.82rem">
            <?= $hasAlerts ? '⚠ Expiry Alerts (' . ((int)$alertAll['expired'] + (int)$alertAll['expiring']) . ')' : 'Expiry Alerts' ?>
        </button>
        <span style="font-size:0.82rem;color:var(--neutral-500)">Expired: <?= (int)$alertAll['expired'] ?> · Expiring: <?= (int)$alertAll['expiring'] ?></span>
    </div>
    <div id="expiry-panel" class="panel" style="display:none;margin-bottom:16px">
        <?php if (!empty($alertBatches)): ?>
        <table>
            <thead><tr><th>Product</th><th>Batch</th><th>Expiry</th><th>Qty</th><th>Status</th></tr></thead>
            <tbody>
                <?php foreach ($alertBatches as $ab):
                    $dl = (int) $ab['days_left'];
                    if ($dl < 0) { $st = 'Expired'; $sc = '#fff'; $sb = '#dc2626'; }
                    elseif ($dl <= 30) { $st = $dl . ' days'; $sc = '#fff'; $sb = '#dc2626'; }
                    else { $st = $dl . ' days'; $sc = '#b91c1c'; $sb = '#fee2e2'; }
                ?>
                <tr>
                    <td><a href="?page=products&edit=<?= $ab['product_id'] ?>" style="font-weight:600;color:var(--brown-800);text-decoration:none"><?= htmlspecialchars($ab['product_name']) ?></a></td>
                    <td><?= htmlspecialchars($ab['batch_number']) ?></td>
                    <td><?= htmlspecialchars($ab['expiry_date']) ?></td>
                    <td><?= (int) $ab['quantity'] ?></td>
                    <td><span style="display:inline-block;padding:2px 8px;border-radius:4px;font-weight:700;font-size:0.82rem;background:<?= $sb ?>;color:<?= $sc ?>"><?= $st ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p style="margin-top:8px;font-size:0.85rem"><a href="?page=expiry_alerts">View all →</a></p>
        <?php else: ?>
        <p class="hint" style="margin:0">No batches expiring within 90 days.</p>
        <?php endif; ?>
    </div>

    <?php if ($batchViewProduct): ?>
        <div class="panel">
            <h2>Batches for <?= htmlspecialchars($batchViewProduct['name']) ?></h2>
            <p><a href="?page=products">← Back to product list</a></p>
            <table>
                <thead><tr><th>Batch #</th><th>Expiry date</th><th>Quantity</th><th>Purchase price</th><th>Added</th></tr></thead>
                <tbody>
                    <?php if (empty($batches)): ?>
                        <tr><td colspan="5">No batches recorded.</td></tr>
                    <?php else: ?>
                        <?php foreach ($batches as $b): ?>
                            <tr>
                                <td><?= htmlspecialchars($b['batch_number']) ?></td>
                                <td<?= strtotime($b['expiry_date']) <= time() + 7776000 ? ' style="color:var(--red-700);font-weight:700"' : '' ?>><?= htmlspecialchars($b['expiry_date']) ?></td>
                                <td><?= htmlspecialchars((string) $b['quantity']) ?></td>
                                <td><?= fmt((float) $b['purchase_price']) ?></td>
                                <td><?= htmlspecialchars($b['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <?php if ($editProduct): ?>
        <div class="panel">
            <h2>Edit product #<?= htmlspecialchars((string) $editProduct['id']) ?></h2>
            <form method="post" class="form-grid" enctype="multipart/form-data" style="max-width:500px">
                <input type="hidden" name="_action" value="update">
                <input type="hidden" name="product_id" value="<?= htmlspecialchars((string) $editProduct['id']) ?>">
                <label>Name<input type="text" name="name" value="<?= htmlspecialchars($editProduct['name']) ?>" required></label>
                <label>Description<textarea name="description"><?= htmlspecialchars((string) ($editProduct['description'] ?? '')) ?></textarea></label>
                <label>Category
                    <select name="category_id">
                        <option value="">No category</option>
                        <?php foreach ($allCategories as $cat): ?>
                            <option value="<?= htmlspecialchars((string) $cat['id']) ?>"<?= (int) ($editProduct['category_id'] ?? 0) === (int) $cat['id'] ? ' selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Photo (leave empty to keep current)<input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif"></label>
                <label>Price (ETB)<input type="number" step="0.01" name="price" value="<?= htmlspecialchars((string) $editProduct['price']) ?>" required></label>
                <label>Stock<input type="number" name="stock" value="<?= htmlspecialchars((string) $editProduct['stock_quantity']) ?>"></label>
                <div>
                    <button type="submit">Update product</button>
                    <a href="?page=products" class="btn-link" style="display:inline-block;padding:12px 20px;color:var(--brown-800);font-weight:700">Cancel</a>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <div class="panel split">
        <div class="panel-block">
            <h2>Add product</h2>
            <form method="post" class="form-grid" enctype="multipart/form-data">
                <input type="hidden" name="_action" value="create">
                <label>Name<input type="text" name="name" required></label>
                <label>Description<textarea name="description"></textarea></label>
                <label>Category
                    <select name="category_id">
                        <option value="">No category</option>
                        <?php foreach ($allCategories as $cat): ?>
                            <option value="<?= htmlspecialchars((string) $cat['id']) ?>"><?= htmlspecialchars($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Photo (JPEG, PNG, WebP, or GIF)<input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif"></label>
                <label>Price (ETB)<input type="number" step="0.01" name="price" required></label>
                <label>Stock<input type="number" name="stock" value="0"></label>
                <hr style="border:none;border-top:1px dashed var(--brown-200);margin:8px 0">
                <p style="font-size:0.85rem;color:var(--brown-700);font-weight:600;margin:0 0 8px">Initial batch (optional)</p>
                <label>Batch #<input type="text" name="batch_number" placeholder="e.g. BATCH001"></label>
                <label>Expiry date<input type="date" name="expiry_date"></label>
                <label>Purchase price (ETB)<input type="number" step="0.01" name="purchase_price" value="0" placeholder="Cost per unit"></label>
                <button type="submit">Create product</button>
            </form>
        </div>

        <div class="panel-block">
            <h2>Product list</h2>
            <form method="get" style="margin-bottom:12px;display:flex;gap:8px;flex-wrap:wrap">
                <input type="hidden" name="page" value="products">
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search products..." style="flex:1;min-width:120px;margin:0">
                <select name="category_id" style="min-width:130px;margin:0">
                    <option value="">All categories</option>
                    <?php foreach ($allCategories as $cat): ?>
                        <option value="<?= htmlspecialchars((string) $cat['id']) ?>"<?= $catFilter === (int) $cat['id'] ? ' selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" style="margin:0">Search</button>
                <?php if ($search !== '' || $catFilter > 0): ?><a href="?page=products" style="display:inline-flex;align-items:center;padding:0 12px;color:var(--brown-800);font-weight:600">Clear</a><?php endif; ?>
            </form>
            <table>
                <thead><tr><th>Photo</th><th>ID</th><th>Name</th><th>Category</th><th>Stock</th><th>Batches</th><th>Price</th><th>Created</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php if (empty($products)): ?>
                        <tr><td colspan="9">No products available.</td></tr>
                    <?php else: ?>
                        <?php foreach ($products as $product): ?>
                            <?php
                            $bStmt = $pdo->prepare('SELECT COUNT(*), COALESCE(MIN(expiry_date), "") FROM product_batches WHERE product_id = :pid AND quantity > 0');
                            $bStmt->execute(['pid' => $product['id']]);
                            list($batchCount, $earliestExpiry) = $bStmt->fetch(PDO::FETCH_NUM);
                            $expiryStatus = '';
                            $expiryColor = '';
                            $expiryBg = '';
                            if ($earliestExpiry !== '') {
                                $expTs = strtotime($earliestExpiry);
                                $daysLeft = round(($expTs - time()) / 86400);
                                if ($daysLeft < 0) {
                                    $expiryStatus = 'Expired';
                                    $expiryColor = '#fff';
                                    $expiryBg = '#dc2626';
                                } elseif ($daysLeft <= 30) {
                                    $expiryStatus = $daysLeft . ' days';
                                    $expiryColor = '#fff';
                                    $expiryBg = '#dc2626';
                                } elseif ($daysLeft <= 90) {
                                    $expiryStatus = $daysLeft . ' days';
                                    $expiryColor = '#b91c1c';
                                    $expiryBg = '#fee2e2';
                                }
                            }
                            ?>
                            <tr>
                                <td class="product-photo-cell">
                                    <?php if (!empty($product['image_path'])): ?>
                                        <img class="product-thumb" src="<?= htmlspecialchars($product['image_path']) ?>" alt="">
                                    <?php else: ?>
                                        <span class="product-thumb-placeholder" title="No photo">—</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars((string) $product['id']) ?></td>
                                <td><?= htmlspecialchars($product['name']) ?></td>
                                <td><?= $product['category_name'] ? htmlspecialchars($product['category_name']) : '<span class="cell-sub">—</span>' ?></td>
                                <td><?= htmlspecialchars((string) $product['stock_quantity']) ?></td>
                                <td style="font-size:0.85rem">
                                    <?php if ((int) $batchCount > 0): ?>
                                        <?= htmlspecialchars((string) $batchCount) ?> batch<?= (int) $batchCount !== 1 ? 'es' : '' ?>
                                        <?php if ($earliestExpiry !== ''): ?>
                                            <br><span class="cell-sub">Exp: <?= htmlspecialchars($earliestExpiry) ?></span>
                                            <?php if ($expiryStatus !== ''): ?>
                                                <br><span style="display:inline-block;margin-top:3px;padding:1px 6px;border-radius:3px;font-weight:700;font-size:0.75rem;background:<?= $expiryBg ?>;color:<?= $expiryColor ?>"><?= $expiryStatus ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="cell-sub">—</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= fmt((float) $product['price']) ?></td>
                                <td><?= htmlspecialchars((string) $product['created_at']) ?></td>
                                <td>
                                    <a href="?page=products&edit=<?= htmlspecialchars((string) $product['id']) ?>" style="color:var(--brown-800);font-weight:700;text-decoration:none">Edit</a>
                                    <a href="?page=products&batches=<?= htmlspecialchars((string) $product['id']) ?>" style="display:inline-block;margin:4px 0;font-size:0.82rem;color:var(--brown-700)">Batches</a>
                                    <form method="post" style="display:inline" onsubmit="return confirm('Delete this product?')">
                                        <input type="hidden" name="_action" value="delete">
                                        <input type="hidden" name="delete_id" value="<?= htmlspecialchars((string) $product['id']) ?>">
                                        <button type="submit" class="btn-danger" style="padding:4px 10px;font-size:0.82rem">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
