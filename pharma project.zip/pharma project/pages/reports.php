<?php
requireAdmin();
$pdo = getPDO();

$dateFrom = trim($_GET['date_from'] ?? '');
$dateTo = trim($_GET['date_to'] ?? '');

$where = [];
$params = [];
if ($dateFrom !== '') {
    $where[] = 's.sale_date >= :date_from';
    $params['date_from'] = $dateFrom;
}
if ($dateTo !== '') {
    $where[] = 's.sale_date <= :date_to';
    $params['date_to'] = $dateTo;
}
$whereClause = !empty($where) ? ' WHERE ' . implode(' AND ', $where) : '';

$summary = $pdo->prepare("SELECT COUNT(*) AS total_sales, COALESCE(SUM(total_amount), 0) AS total_revenue, COALESCE(AVG(total_amount), 0) AS avg_sale FROM sales s$whereClause");
$summary->execute($params);
$summaryData = $summary->fetch();

$byCustomer = $pdo->prepare("SELECT c.name, COUNT(*) AS sale_count, SUM(s.total_amount) AS total FROM sales s JOIN customers c ON s.customer_id = c.id$whereClause GROUP BY s.customer_id ORDER BY total DESC LIMIT 20");
$byCustomer->execute($params);
$byCustomerRows = $byCustomer->fetchAll();

$byProduct = $pdo->prepare("SELECT p.name, SUM(si.quantity) AS qty_sold, SUM(si.quantity * si.unit_price) AS revenue FROM sale_items si JOIN products p ON si.product_id = p.id JOIN sales s ON si.sale_id = s.id$whereClause GROUP BY si.product_id ORDER BY revenue DESC LIMIT 20");
$byProduct->execute($params);
$byProductRows = $byProduct->fetchAll();

$daily = $pdo->prepare("SELECT s.sale_date, COUNT(*) AS sale_count, SUM(s.total_amount) AS daily_total FROM sales s$whereClause GROUP BY s.sale_date ORDER BY s.sale_date DESC LIMIT 60");
$daily->execute($params);
$dailyRows = $daily->fetchAll();
?>
<section>
    <h1>Sales reports</h1>

    <div class="panel">
        <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
            <input type="hidden" name="page" value="reports">
            <label style="margin:0">From<input type="date" name="date_from" value="<?= htmlspecialchars($dateFrom) ?>" style="margin:0"></label>
            <label style="margin:0">To<input type="date" name="date_to" value="<?= htmlspecialchars($dateTo) ?>" style="margin:0"></label>
            <button type="submit" style="margin:0">Generate</button>
            <?php if ($dateFrom !== '' || $dateTo !== ''): ?><a href="?page=reports" style="display:inline-flex;align-items:center;padding:12px;color:var(--brown-800);font-weight:600">Clear</a><?php endif; ?>
        </form>
    </div>

    <div class="grid cards cards-5">
        <div class="card"><h2>Total sales</h2><p><?= htmlspecialchars((string) $summaryData['total_sales']) ?></p></div>
        <div class="card"><h2>Total revenue</h2><p><?= number_format((float) $summaryData['total_revenue'], 2) ?></p></div>
        <div class="card"><h2>Average sale</h2><p><?= number_format((float) $summaryData['avg_sale'], 2) ?></p></div>
    </div>

    <div class="panel split">
        <div class="panel-block">
            <h2>Sales by customer</h2>
            <table>
                <thead><tr><th>Customer</th><th>Sales</th><th>Total</th></tr></thead>
                <tbody>
                    <?php if (empty($byCustomerRows)): ?>
                        <tr><td colspan="3">No data.</td></tr>
                    <?php else: ?>
                        <?php foreach ($byCustomerRows as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['name']) ?></td>
                                <td><?= htmlspecialchars((string) $row['sale_count']) ?></td>
                                <td><?= number_format((float) $row['total'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="panel-block">
            <h2>Top selling products</h2>
            <table>
                <thead><tr><th>Product</th><th>Qty sold</th><th>Revenue</th></tr></thead>
                <tbody>
                    <?php if (empty($byProductRows)): ?>
                        <tr><td colspan="3">No data.</td></tr>
                    <?php else: ?>
                        <?php foreach ($byProductRows as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['name']) ?></td>
                                <td><?= htmlspecialchars((string) $row['qty_sold']) ?></td>
                                <td><?= number_format((float) $row['revenue'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="panel">
        <h2>Daily sales breakdown</h2>
        <table>
            <thead><tr><th>Date</th><th>Sales count</th><th>Daily total</th></tr></thead>
            <tbody>
                <?php if (empty($dailyRows)): ?>
                    <tr><td colspan="3">No data.</td></tr>
                <?php else: ?>
                    <?php foreach ($dailyRows as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['sale_date']) ?></td>
                            <td><?= htmlspecialchars((string) $row['sale_count']) ?></td>
                            <td><?= number_format((float) $row['daily_total'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
