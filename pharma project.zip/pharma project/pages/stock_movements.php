<?php
requireAdmin();
require_once __DIR__ . '/../includes/stock_helper.php';
$pdo = getPDO();

$from  = $_GET['from'] ?? date('Y-m-d', strtotime('-30 days'));
$to    = $_GET['to'] ?? date('Y-m-d');
$search = $_GET['search'] ?? '';

$sql = 'SELECT sm.*, p.name AS product_name FROM stock_movements sm LEFT JOIN products p ON sm.product_id = p.id WHERE DATE(sm.created_at) >= :from AND DATE(sm.created_at) <= :to';
$params = ['from' => $from, 'to' => $to];

if ($search !== '') {
    $sql .= ' AND (p.name LIKE :search OR sm.reason LIKE :search2)';
    $params['search'] = "%$search%";
    $params['search2'] = "%$search%";
}

$sql .= ' ORDER BY sm.created_at DESC';
$movements = $pdo->prepare($sql);
$movements->execute($params);
$rows = $movements->fetchAll();

?>
<h2>Stock Movements</h2>

<form method="GET" class="filter-form" style="margin-bottom:20px;">
    <input type="hidden" name="page" value="stock_movements">
    <label>From: <input type="date" name="from" value="<?= htmlspecialchars($from) ?>"></label>
    <label>To: <input type="date" name="to" value="<?= htmlspecialchars($to) ?>"></label>
    <label>Search: <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="product or reason..."></label>
    <button type="submit" class="btn">Filter</button>
    <a href="?page=stock_movements" class="btn btn-secondary">Reset</a>
</form>

<div class="table-responsive">
<table class="table">
    <thead>
        <tr>
            <th>Date/Time</th>
            <th>Product</th>
            <th>Quantity</th>
            <th>Reason</th>
            <th>Reference</th>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($rows)): ?>
        <tr><td colspan="5">No stock movements found.</td></tr>
    <?php else: ?>
        <?php foreach ($rows as $r): ?>
            <?php
                $qty = (int) $r['quantity_change'];
                $qtyClass = $qty >= 0 ? 'text-success' : 'text-danger';
                $qtyDisplay = $qty >= 0 ? '+' . $qty : (string) $qty;
            ?>
            <tr>
                <td><?= htmlspecialchars($r['created_at']) ?></td>
                <td><a href="?page=products&edit=<?= $r['product_id'] ?>"><?= htmlspecialchars($r['product_name'] ?? 'Deleted #'.$r['product_id']) ?></a></td>
                <td class="<?= $qtyClass ?>" style="font-weight:bold;"><?= $qtyDisplay ?></td>
                <td><?= htmlspecialchars($r['reason']) ?></td>
                <td>
                    <?php if ($r['reference_type'] && $r['reference_id']): ?>
                        <?= htmlspecialchars($r['reference_type']) ?> #<?= $r['reference_id'] ?>
                    <?php else: ?>
                        &mdash;
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>
</div>
