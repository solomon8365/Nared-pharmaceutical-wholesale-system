<?php
$pdo = getPDO();
$catFilter = (int) ($_GET['category_id'] ?? 0);
$allCats = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
$sql = 'SELECT p.id, p.name, p.description, p.image_path, p.price, p.stock_quantity, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id';
$params = [];
if ($catFilter > 0) {
    $sql .= ' WHERE p.category_id = :cat';
    $params['cat'] = $catFilter;
}
$sql .= ' ORDER BY p.name';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
$user = currentUser();

$batchMap = [];
if (!empty($products)) {
    $ids = array_column($products, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $bStmt = $pdo->prepare("SELECT product_id, batch_number, expiry_date, quantity FROM product_batches WHERE product_id IN ($placeholders) AND quantity > 0 ORDER BY expiry_date ASC");
    $bStmt->execute($ids);
    foreach ($bStmt->fetchAll() as $b) {
        $pid = (int) $b['product_id'];
        if (!isset($batchMap[$pid])) $batchMap[$pid] = [];
        if (count($batchMap[$pid]) < 3) $batchMap[$pid][] = $b;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
    <style>
        .catalog-desc-wrap { position:relative; }
        .catalog-see-more { background:none;border:none;color:var(--brown-700);font-weight:600;font-size:0.8rem;cursor:pointer;padding:0;margin-top:4px; }
        .catalog-see-more:hover { text-decoration:underline; }
    </style>
</head>
<body class="login-page catalog-page">
<div class="catalog-wrap">
    <div class="catalog-header">
        <h1>Product catalog</h1>
        <nav class="catalog-nav">
            <?php if ($user && isCustomer()): ?>
                <a href="index.php?page=dashboard">Dashboard</a>
                <a href="index.php?page=place_order">Place order</a>
                <a href="index.php?page=my_orders">My orders</a>
                <a href="index.php?page=logout" class="logout">Logout</a>
            <?php elseif ($user && isAdmin()): ?>
                <a href="index.php?page=dashboard">Admin dashboard</a>
                <a href="index.php?page=logout" class="logout">Logout</a>
            <?php else: ?>
                <a href="index.php?page=login">Sign in</a>
                <a href="index.php?page=register">Register</a>
            <?php endif; ?>
        </nav>
    </div>

    <form method="get" style="margin-bottom:18px;display:flex;gap:8px;flex-wrap:wrap">
        <select name="category_id" style="min-width:160px">
            <option value="">All categories</option>
            <?php foreach ($allCats as $cat): ?>
                <option value="<?= htmlspecialchars((string) $cat['id']) ?>"<?= $catFilter === (int) $cat['id'] ? ' selected' : '' ?>><?= htmlspecialchars($cat['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Filter</button>
        <?php if ($catFilter > 0): ?><a href="?page=catalog" style="display:inline-flex;align-items:center;padding:0 12px;color:var(--brown-800);font-weight:600">Clear</a><?php endif; ?>
    </form>

    <?php if (empty($products)): ?>
        <p>No products listed yet. Check back soon.</p>
    <?php else: ?>
        <div class="catalog-grid">
            <?php foreach ($products as $p): ?>
                <article class="catalog-card">
                    <div class="catalog-card-image">
                        <?php if (!empty($p['image_path'])): ?>
                            <img src="<?= htmlspecialchars($p['image_path']) ?>" alt="">
                        <?php else: ?>
                            <span class="catalog-no-img">No image</span>
                        <?php endif; ?>
                    </div>
                    <h2><?= htmlspecialchars($p['name']) ?></h2>
                    <?php if (!empty($p['category_name'])): ?>
                        <p class="catalog-desc" style="font-weight:600;color:var(--brown-700);margin:0 0 6px"><?= htmlspecialchars($p['category_name']) ?></p>
                    <?php endif; ?>
                    <?php
                    $rawDesc = (string) ($p['description'] ?? '');
                    $descId = 'desc-' . $p['id'];
                    $words = explode(' ', $rawDesc);
                    $shortDesc = count($words) > 3 ? implode(' ', array_slice($words, 0, 3)) . '...' : '';
                    ?>
                    <?php if ($rawDesc !== ''): ?>
                        <div class="catalog-desc-wrap">
                            <?php if ($shortDesc !== ''): ?>
                                <p class="catalog-desc" id="<?= $descId ?>-short"><?= htmlspecialchars($shortDesc) ?></p>
                                <p class="catalog-desc" id="<?= $descId ?>-full" style="display:none"><?= nl2br(htmlspecialchars($rawDesc)) ?></p>
                                <button class="catalog-see-more" onclick="toggleDesc('<?= $descId ?>')" id="<?= $descId ?>-btn">See more</button>
                            <?php else: ?>
                                <p class="catalog-desc"><?= nl2br(htmlspecialchars($rawDesc)) ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <p class="catalog-meta"><strong><?= fmt((float) $p['price']) ?></strong></p>
                    <?php
                    $pBatches = $batchMap[(int) $p['id']] ?? [];
                    if (!empty($pBatches)): ?>
                        <div style="margin:0 0 10px;font-size:0.78rem;">
                            <?php foreach ($pBatches as $b): ?>
                                <span style="display:inline-block;margin:2px 4px 2px 0;padding:2px 6px;border-radius:4px;background:<?= strtotime($b['expiry_date']) <= strtotime('+90 days') ? 'var(--red-100)' : 'var(--brown-100)' ?>;color:<?= strtotime($b['expiry_date']) <= time() ? 'var(--red-700)' : 'var(--brown-800)' ?>">
                                    <?= htmlspecialchars($b['batch_number']) ?> (exp: <?= htmlspecialchars($b['expiry_date']) ?>)
                                </span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <?php
                    $pid = (int) $p['id'];
                    if ($user && isCustomer()) {
                        $orderHref = 'index.php?page=place_order&product_id=' . $pid;
                        ?>
                        <a class="catalog-order-btn" href="<?= htmlspecialchars($orderHref) ?>">Order this product</a>
                        <?php
                    } else {
                        $loginHref = 'index.php?page=login&redirect=place_order&product_id=' . $pid;
                        $registerHref = 'index.php?page=register&redirect=place_order&product_id=' . $pid;
                        ?>
                        <div class="catalog-guest-actions">
                            <a class="catalog-order-btn" href="<?= htmlspecialchars($loginHref) ?>">Sign in to order</a>
                            <a class="catalog-register-btn" href="<?= htmlspecialchars($registerHref) ?>">Register to order</a>
                        </div>
                        <?php
                    }
                    ?>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<script>
function toggleDesc(id) {
    var short = document.getElementById(id + '-short');
    var full = document.getElementById(id + '-full');
    var btn = document.getElementById(id + '-btn');
    if (!short || !full || !btn) return;
    if (full.style.display === 'none') {
        short.style.display = 'none';
        full.style.display = 'block';
        btn.textContent = 'See less';
    } else {
        short.style.display = 'block';
        full.style.display = 'none';
        btn.textContent = 'See more';
    }
}
</script>
</body>
</html>
