<?php
requireCustomer();
$pdo = getPDO();
$messages = [];
$cid = customerAccountCustomerId();
$products = $pdo->query('SELECT id, name, price, stock_quantity FROM products ORDER BY name')->fetchAll();

$prefillPid = isset($_GET['product_id']) ? (int) $_GET['product_id'] : 0;
$validPre = false;
if ($prefillPid > 0) {
    foreach ($products as $p) {
        if ((int) $p['id'] === $prefillPid) {
            $validPre = true;
            break;
        }
    }
}
if (!$validPre) {
    $prefillPid = 0;
}

if ($cid === null) {
    $messages[] = ['type' => 'error', 'text' => 'Your login is not linked to a customer record. Ask an administrator to create a customer login for you.'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $cid !== null) {
    $orderDate = $_POST['order_date'] ?? date('Y-m-d');
    $items = $_POST['request_items'] ?? [];
    $uid = (int) (currentUser()['id'] ?? 0);
    $paymentMethod = $_POST['payment_method'] ?? 'bank';
    $paymentMethod = in_array($paymentMethod, ['bank', 'telebirr'], true) ? $paymentMethod : 'bank';
    $paymentDetail = trim($_POST['payment_detail'] ?? '');

    if ($paymentDetail === '') {
        $messages[] = ['type' => 'error', 'text' => 'Please enter payment details (bank account info or Telebirr phone number).'];
    }

    $lineTotals = [];
    foreach ($items as $item) {
        $productId = (int) ($item['product_id'] ?? 0);
        $quantity = (int) ($item['quantity'] ?? 0);
        if ($productId <= 0 || $quantity <= 0) {
            continue;
        }
        $lineTotals[] = ['product_id' => $productId, 'quantity' => $quantity];
    }

    if (empty($messages) && empty($lineTotals)) {
        $messages[] = ['type' => 'error', 'text' => 'Add at least one product with quantity.'];
    } elseif (empty($messages)) {
        $pdo->beginTransaction();
        try {
            $qtyByProduct = [];
            foreach ($lineTotals as $line) {
                $pid = $line['product_id'];
                $qtyByProduct[$pid] = ($qtyByProduct[$pid] ?? 0) + $line['quantity'];
            }

            $priceByProduct = [];
            foreach ($qtyByProduct as $productId => $_need) {
                $stmt = $pdo->prepare('SELECT price FROM products WHERE id = :id');
                $stmt->execute(['id' => $productId]);
                $price = $stmt->fetchColumn();
                if ($price === false) {
                    throw new RuntimeException('Invalid product in order.');
                }
                $priceByProduct[$productId] = (float) $price;
            }

            $linesForInsert = [];
            foreach ($lineTotals as $line) {
                $linesForInsert[] = [
                    'product_id' => $line['product_id'],
                    'quantity' => $line['quantity'],
                    'unit_price' => $priceByProduct[$line['product_id']],
                ];
            }

            $total = 0;
            foreach ($linesForInsert as $line) {
                $total += $line['unit_price'] * $line['quantity'];
            }

            $stmt = $pdo->prepare("INSERT INTO customer_orders (customer_id, placed_by_user_id, order_date, status, total_amount, payment_method, payment_detail, created_at) VALUES (:cid, :uid, :od, 'pending', :total, :pm, :pd, NOW())");
            $stmt->execute([
                'cid' => $cid,
                'uid' => $uid,
                'od' => $orderDate,
                'total' => $total,
                'pm' => $paymentMethod,
                'pd' => $paymentDetail,
            ]);
            $orderId = (int) $pdo->lastInsertId();

            $ins = $pdo->prepare('INSERT INTO customer_order_items (customer_order_id, product_id, quantity, unit_price) VALUES (:oid, :pid, :qty, :price)');
            foreach ($linesForInsert as $line) {
                $ins->execute([
                    'oid' => $orderId,
                    'pid' => $line['product_id'],
                    'qty' => $line['quantity'],
                    'price' => $line['unit_price'],
                ]);
            }

            $pdo->commit();
            $messages[] = ['type' => 'success', 'text' => 'Order submitted for approval. You will see the status under My orders.'];
        } catch (Exception $e) {
            $pdo->rollBack();
            $messages[] = ['type' => 'error', 'text' => $e->getMessage()];
        }
    }
}
?>
<section>
    <h1>Place order</h1>
    <?php foreach ($messages as $message): ?>
        <div class="alert alert-<?= htmlspecialchars($message['type']) ?>"><?= htmlspecialchars($message['text']) ?></div>
    <?php endforeach; ?>

    <?php if ($cid === null): ?>
        <div class="panel"><p>You cannot place orders until an administrator links your account to a customer profile.</p></div>
    <?php elseif (empty($products)): ?>
        <div class="panel"><p>No products are available yet.</p></div>
    <?php else: ?>
    <div class="panel">
        <p><a href="index.php?page=catalog">Browse product catalog</a> (with photos) and use “Order this product” to pre-fill a line here.</p>
        <h2>New request</h2>
        <p class="hint">Stock is not reserved until an administrator approves your order.</p>
        <form method="post" class="form-grid" id="request-form">
            <label>Order date<input type="date" name="order_date" value="<?= date('Y-m-d') ?>"></label>
            <label>Payment method
                <select name="payment_method" required>
                    <option value="bank" <?= ($_POST['payment_method'] ?? 'bank') === 'bank' ? 'selected' : '' ?>>Bank transfer</option>
                    <option value="telebirr" <?= ($_POST['payment_method'] ?? '') === 'telebirr' ? 'selected' : '' ?>>Telebirr</option>
                </select>
            </label>
            <label>Payment details
                <textarea name="payment_detail" rows="3" required placeholder="For bank: bank name, account name, account number. For Telebirr: phone number registered with Telebirr."><?= htmlspecialchars($_POST['payment_detail'] ?? '') ?></textarea>
            </label>
            <div class="order-items" id="request-items">
                <div class="order-item-row">
                    <select name="request_items[0][product_id]" required>
                        <option value="">Select product</option>
                        <?php foreach ($products as $product): ?>
                            <option value="<?= htmlspecialchars((string) $product['id']) ?>"<?= (int) $product['id'] === $prefillPid ? ' selected' : '' ?>><?= htmlspecialchars($product['name']) ?> — <?= number_format((float) $product['price'], 2) ?> (stock <?= (int) $product['stock_quantity'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                    <input type="number" name="request_items[0][quantity]" value="1" min="1" required>
                    <button type="button" class="remove-item">Remove</button>
                </div>
            </div>
            <button type="button" id="add-request-item">Add item</button>
            <button type="submit">Submit for approval</button>
        </form>
    </div>
    <?php endif; ?>
</section>
