<?php
if (currentUser()) {
    header('Location: index.php?page=dashboard');
    exit;
}

$pdo = getPDO();
$errors = [];
$safeRedirect = (($_POST['after_register'] ?? $_GET['redirect'] ?? '') === 'place_order') ? 'place_order' : '';
$productAfter = (int) ($_POST['product_id_after'] ?? $_GET['product_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $businessName = trim($_POST['business_name'] ?? '');
    $contactPerson = trim($_POST['contact_person'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password_confirm'] ?? '';

    if ($businessName === '' || $phone === '' || $username === '' || $password === '') {
        $errors[] = 'Business name, phone, username, and password are required.';
    } elseif (strlen($username) < 3) {
        $errors[] = 'Username must be at least 3 characters.';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    } elseif ($password !== $password2) {
        $errors[] = 'Passwords do not match.';
    } else {
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('INSERT INTO customers (name, contact_person, phone, created_at) VALUES (:name, :contact, :phone, NOW())');
            $stmt->execute([
                'name' => $businessName,
                'contact' => $contactPerson !== '' ? $contactPerson : null,
                'phone' => $phone,
            ]);
            $customerId = (int) $pdo->lastInsertId();

            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, role, customer_id, created_at) VALUES (:u, :p, :fn, 'customer', :cid, NOW())");
            $stmt->execute([
                'u' => $username,
                'p' => $hash,
                'fn' => $businessName,
                'cid' => $customerId,
            ]);

            $pdo->commit();

            if (loginForPortal($username, $password, 'customer') !== null) {
                header('Location: index.php?page=customer_login');
                exit;
            }

            if ($safeRedirect === 'place_order') {
                $url = 'index.php?page=place_order';
                if ($productAfter > 0) {
                    $url .= '&product_id=' . $productAfter;
                }
                header('Location: ' . $url);
                exit;
            }

            header('Location: index.php?page=dashboard');
            exit;
        } catch (PDOException $e) {
            $pdo->rollBack();
            if (($e->errorInfo[1] ?? 0) === 1062) {
                $errors[] = 'That username is already taken.';
            } else {
                $errors[] = 'Registration failed. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
<div class="login-panel register-panel">
    <h1>Create customer account</h1>
    <p class="hint" style="margin-top:-12px;">Register once, then sign in anytime to browse products and submit orders.</p>
    <?php if (!empty($errors)): ?>
        <div class="alert alert-error"><?= htmlspecialchars(implode(' ', $errors)) ?></div>
    <?php endif; ?>
    <form method="post" action="index.php?page=register">
        <input type="hidden" name="after_register" value="<?= htmlspecialchars($safeRedirect) ?>">
        <input type="hidden" name="product_id_after" value="<?= $productAfter > 0 ? htmlspecialchars((string) $productAfter) : '' ?>">
        <label>Business / pharmacy name<input type="text" name="business_name" value="<?= htmlspecialchars($_POST['business_name'] ?? '') ?>" required></label>
        <label>Contact person<input type="text" name="contact_person" value="<?= htmlspecialchars($_POST['contact_person'] ?? '') ?>"></label>
        <label>Phone<input type="text" name="phone" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required></label>
        <label>Username<input type="text" name="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required minlength="3" autocomplete="username"></label>
        <label>Password<input type="password" name="password" required minlength="6" autocomplete="new-password"></label>
        <label>Confirm password<input type="password" name="password_confirm" required minlength="6" autocomplete="new-password"></label>
        <label class="pw-toggle"><input type="checkbox"> Show passwords</label>
        <button type="submit">Register</button>
    </form>
    <p class="login-alt-links"><a href="index.php?page=login">Already have an account? Sign in</a> · <a href="index.php?page=catalog">Browse products</a></p>
</div>
<script>
document.querySelector('form').addEventListener('submit', function(e) {
    var els = {
        bn: this.querySelector('[name="business_name"]'),
        ph: this.querySelector('[name="phone"]'),
        un: this.querySelector('[name="username"]'),
        pw: this.querySelector('[name="password"]'),
        pc: this.querySelector('[name="password_confirm"]')
    };
    var valid = true;
    Object.keys(els).forEach(function(k) {
        var el = els[k];
        el.classList.remove('error');
        var err = el.parentNode.querySelector('.field-error');
        if (err) err.style.display = 'none';
    });
    if (els.bn.value.trim() === '') { els.bn.classList.add('error'); valid = false; }
    if (els.ph.value.trim() === '') { els.ph.classList.add('error'); valid = false; }
    if (els.un.value.trim() === '') { els.un.classList.add('error'); valid = false; }
    else if (els.un.value.trim().length < 3) { els.un.classList.add('error'); valid = false; }
    if (els.pw.value.trim() === '') { els.pw.classList.add('error'); valid = false; }
    else if (els.pw.value.length < 6) { els.pw.classList.add('error'); valid = false; }
    if (els.pc.value !== els.pw.value) { els.pc.classList.add('error'); valid = false; }
    if (!valid) e.preventDefault();
    else this.querySelector('button[type="submit"]').classList.add('loading');
});
document.querySelectorAll('.pw-toggle input[type="checkbox"]').forEach(function(cb) {
    cb.addEventListener('change', function() {
        var f = this.closest('form');
        ['[name="password"]', '[name="password_confirm"]'].forEach(function(sel) {
            var p = f.querySelector(sel);
            if (p) p.type = cb.checked ? 'text' : 'password';
        });
    });
});
</script>
</body>
</html>
