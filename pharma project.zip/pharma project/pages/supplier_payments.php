<?php
requireAdmin();
$pdo = getPDO();

$from = $_GET['from'] ?? date('Y-m-d', strtotime('-90 days'));
$to   = $_GET['to'] ?? date('Y-m-d');
$supplierFilter = (int) ($_GET['supplier_id'] ?? 0);

$sql = 'SELECT sp.*, o.total_amount, o.order_date AS order_date, s.name AS supplier_name FROM supplier_payments sp JOIN orders o ON sp.order_id = o.id LEFT JOIN suppliers s ON o.supplier_id = s.id WHERE DATE(sp.created_at) >= :from AND DATE(sp.created_at) <= :to';
$params = ['from' => $from, 'to' => $to];

if ($supplierFilter > 0) {
    $sql .= ' AND o.supplier_id = :sid';
    $params['sid'] = $supplierFilter;
}

$sql .= ' ORDER BY sp.created_at DESC';
$rows = $pdo->prepare($sql);
$rows->execute($params);
$payments = $rows->fetchAll();

$suppliers = $pdo->query('SELECT id, name FROM suppliers ORDER BY name')->fetchAll();
?>
<h2>Supplier Payments</h2>

<form method="GET" class="filter-form" style="margin-bottom:20px;">
    <input type="hidden" name="page" value="supplier_payments">
    <label>Supplier:
        <select name="supplier_id">
            <option value="">All suppliers</option>
            <?php foreach ($suppliers as $s): ?>
                <option value="<?= $s['id'] ?>" <?= $supplierFilter === (int) $s['id'] ? 'selected' : '' ?>><?= htmlspecialchars($s['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>From: <input type="date" name="from" value="<?= htmlspecialchars($from) ?>"></label>
    <label>To: <input type="date" name="to" value="<?= htmlspecialchars($to) ?>"></label>
    <button type="submit" class="btn">Filter</button>
    <a href="?page=supplier_payments" class="btn btn-secondary">Reset</a>
</form>

<div class="table-responsive">
<table class="table">
    <thead>
        <tr>
            <th>Date</th>
            <th>Supplier</th>
            <th>Order #</th>
            <th>Order Total</th>
            <th>Amount Paid</th>
            <th>Method</th>
            <th>Reference</th>
            <th>Notes</th>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($payments)): ?>
        <tr><td colspan="8">No payments recorded.</td></tr>
    <?php else: ?>
        <?php foreach ($payments as $p): ?>
            <tr>
                <td><?= htmlspecialchars($p['payment_date']) ?></td>
                <td><?= htmlspecialchars($p['supplier_name'] ?? 'Unknown') ?></td>
                <td><a href="?page=orders">#<?= (int) $p['order_id'] ?></a></td>
                <td><?= fmt((float) $p['total_amount']) ?></td>
                <td style="font-weight:700;color:var(--brown-700)"><?= fmt((float) $p['amount_paid']) ?></td>
                <td><?= $p['payment_method'] ? htmlspecialchars($p['payment_method']) : '—' ?></td>
                <td><?= $p['reference'] ? htmlspecialchars($p['reference']) : '—' ?></td>
                <td><?= $p['notes'] ? htmlspecialchars($p['notes']) : '—' ?></td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>
</div>
