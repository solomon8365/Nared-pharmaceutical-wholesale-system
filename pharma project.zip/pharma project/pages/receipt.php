<?php
requireAdmin();
require_once __DIR__ . '/../config.php';
$pdo = getPDO();
$saleId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($saleId <= 0) {
    header('Location: index.php?page=sales');
    exit;
}

$stmt = $pdo->prepare('SELECT s.*, c.name AS customer_name FROM sales s LEFT JOIN customers c ON s.customer_id = c.id WHERE s.id = :id');
$stmt->execute(['id' => $saleId]);
$sale = $stmt->fetch();

if (!$sale) {
    header('Location: index.php?page=sales');
    exit;
}

$itemsStmt = $pdo->prepare('SELECT si.quantity, si.unit_price, p.name AS product_name FROM sale_items si JOIN products p ON si.product_id = p.id WHERE si.sale_id = :id');
$itemsStmt->execute(['id' => $saleId]);
$items = $itemsStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt #<?= htmlspecialchars((string) $saleId) ?> - <?= htmlspecialchars(APP_NAME) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { background: var(--white); margin: 0; padding: 20px; font-size: 14px; }
        .receipt { max-width: 700px; margin: 0 auto; padding: 30px; border: 2px solid var(--brown-200); border-radius: var(--radius-lg); }
        .receipt-header { text-align: center; border-bottom: 3px double var(--brown-800); padding-bottom: 16px; margin-bottom: 20px; }
        .receipt-header h1 { margin: 0 0 4px; color: var(--brown-900); font-size: 1.4rem; border: none; display: block; }
        .receipt-header .receipt-no { font-size: 0.95rem; color: var(--neutral-700); margin-top: 4px; }
        .receipt-meta { display: flex; justify-content: space-between; margin-bottom: 18px; font-size: 0.92rem; }
        .receipt-meta div { line-height: 1.6; }
        .receipt table { width: 100%; border-collapse: collapse; margin-bottom: 18px; }
        .receipt th { background: var(--brown-800); color: var(--white); padding: 10px 8px; text-align: left; font-size: 0.82rem; }
        .receipt td { padding: 10px 8px; border-bottom: 1px solid var(--neutral-200); }
        .receipt tbody tr:last-child td { border-bottom: 2px solid var(--brown-800); }
        .receipt .amount { text-align: right; }
        .receipt .total-row td { font-weight: 800; font-size: 1.1rem; color: var(--brown-900); padding-top: 12px; }
        .receipt-footer { text-align: center; margin-top: 24px; color: var(--neutral-500); font-size: 0.88rem; border-top: 1px solid var(--brown-200); padding-top: 16px; }
        .no-print { text-align: center; margin-bottom: 16px; }
        @media print {
            .no-print { display: none; }
            body { padding: 0; }
            .receipt { border: none; border-radius: 0; padding: 20px; }
        }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()" style="background:var(--brown-700);color:var(--white);border:none;padding:10px 24px;border-radius:6px;cursor:pointer;font-weight:700;font-size:1rem">Print / Save PDF</button>
        <a href="index.php?page=sales" style="display:inline-block;margin-left:12px;color:var(--brown-800);font-weight:600">← Back to sales</a>
    </div>
    <div class="receipt">
        <div class="receipt-header">
            <h1><?= htmlspecialchars(APP_NAME) ?></h1>
            <div class="receipt-no">Receipt #<?= htmlspecialchars((string) $saleId) ?></div>
        </div>
        <div class="receipt-meta">
            <div>
                <strong>Customer:</strong> <?= htmlspecialchars($sale['customer_name'] ?? 'N/A') ?><br>
            </div>
            <div style="text-align:right">
                <strong>Date:</strong> <?= htmlspecialchars($sale['sale_date']) ?><br>
            </div>
        </div>
        <table>
            <thead>
                <tr><th>Product</th><th class="amount">Qty</th><th class="amount">Unit price</th><th class="amount">Total</th></tr>
            </thead>
            <tbody>
                <?php
                $subtotal = 0;
                foreach ($items as $item):
                    $lineTotal = (float) $item['unit_price'] * (int) $item['quantity'];
                    $subtotal += $lineTotal;
                ?>
                <tr>
                    <td><?= htmlspecialchars($item['product_name']) ?></td>
                    <td class="amount"><?= htmlspecialchars((string) $item['quantity']) ?></td>
                    <td class="amount"><?= number_format((float) $item['unit_price'], 2) ?></td>
                    <td class="amount"><?= number_format($lineTotal, 2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="total-row">
                    <td colspan="3" style="text-align:right">Total:</td>
                    <td class="amount"><?= number_format($subtotal, 2) ?></td>
                </tr>
            </tfoot>
        </table>
        <div class="receipt-footer">
            Thank you for your business!<br>
            <?= htmlspecialchars(APP_NAME) ?>
        </div>
    </div>
</body>
</html>
