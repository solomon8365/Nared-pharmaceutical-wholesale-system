<?php
requireCustomer();
$pdo = getPDO();
$cid = customerAccountCustomerId();

if ($cid === null) {
    $rows = [];
} else {
    $stmt = $pdo->prepare('SELECT id, order_date, total_amount, status, payment_method, payment_detail, admin_note, created_at, processed_at FROM customer_orders WHERE customer_id = :cid ORDER BY created_at DESC');
    $stmt->execute(['cid' => $cid]);
    $rows = $stmt->fetchAll();
}
?>
<section>
    <h1>My orders</h1>
    <?php if ($cid === null): ?>
        <div class="panel"><p>Your account is not linked to a customer profile. Contact an administrator.</p></div>
    <?php else: ?>
    <div class="panel">
        <table>
            <thead><tr><th>ID</th><th>Date</th><th>Total</th><th>Pay</th><th>Status</th><th>Note</th><th>Updated</th></tr></thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="7">You have not placed any orders yet. <a href="index.php?page=catalog">Browse products</a> or <a href="index.php?page=place_order">place an order</a>.</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td><?= htmlspecialchars((string) $r['id']) ?></td>
                            <td><?= htmlspecialchars($r['order_date']) ?></td>
                            <td><?= number_format((float) $r['total_amount'], 2) ?></td>
                            <td><?= htmlspecialchars($r['payment_method'] ?? '') ?>
                                <?php
                                $pd = (string) ($r['payment_detail'] ?? '');
                                if ($pd !== '') {
                                    if (strlen($pd) > 45) {
                                        $pd = substr($pd, 0, 42) . '…';
                                    }
                                    echo '<br><span class="cell-sub">' . htmlspecialchars($pd) . '</span>';
                                }
                                ?></td>
                            <td><span class="status-badge status-<?= htmlspecialchars($r['status']) ?>"><?= htmlspecialchars($r['status']) ?></span></td>
                            <td><?= $r['admin_note'] ? htmlspecialchars($r['admin_note']) : '—' ?></td>
                            <td><?= $r['processed_at'] ? htmlspecialchars($r['processed_at']) : '—' ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</section>
